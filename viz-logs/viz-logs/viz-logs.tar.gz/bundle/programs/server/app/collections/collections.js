(function(){
TestLogs = new Mongo.Collection("testLogs");
ReceiverLogs = new Mongo.Collection("receiverLogs");
NativeLogs = new Mongo.Collection("nativeLogs");

})();
