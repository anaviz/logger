(function(){
WebLogs = new Mongo.Collection("webLogs");
ReceiverLogs = new Mongo.Collection("receiverLogs");
NativeLogs = new Mongo.Collection("nativeLogs");

})();
