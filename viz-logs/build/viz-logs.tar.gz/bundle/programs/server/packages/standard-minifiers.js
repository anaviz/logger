(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['standard-minifiers'] = {};

})();

//# sourceMappingURL=standard-minifiers.js.map
