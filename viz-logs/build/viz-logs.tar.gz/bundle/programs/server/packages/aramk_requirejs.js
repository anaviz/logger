(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var define, require, requirejs;

(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/aramk_requirejs/packages/aramk_requirejs.js                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
(function () {                                                                                                         // 1
                                                                                                                       // 2
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////      // 3
//                                                                                                             //      // 4
// packages/aramk:requirejs/require.js                                                                         //      // 5
//                                                                                                             //      // 6
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////      // 7
                                                                                                               //      // 8
(function (global) {                                                                                           // 1    // 9
                                                                                                               // 2    // 10
// Return global exports for Meteor.                                                                           // 3    // 11
var exports = (function () {                                                                                   // 4    // 12
                                                                                                               // 5    // 13
////////////////////////////////////////////////////////////////////////////////////////////////////           // 6    // 14
// START ORGINAL SCRIPT                                                                                        // 7    // 15
////////////////////////////////////////////////////////////////////////////////////////////////////           // 8    // 16
                                                                                                               // 9    // 17
/** vim: et:ts=4:sw=4:sts=4                                                                                    // 10   // 18
 * @license RequireJS 2.1.15 Copyright (c) 2010-2014, The Dojo Foundation All Rights Reserved.                 // 11   // 19
 * Available via the MIT or new BSD license.                                                                   // 12   // 20
 * see: http://github.com/jrburke/requirejs for details                                                        // 13   // 21
 */                                                                                                            // 14   // 22
//Not using strict: uneven strict support in browsers, #392, and causes                                        // 15   // 23
//problems with requirejs.exec()/transpiler plugins that may not be strict.                                    // 16   // 24
/*jslint regexp: true, nomen: true, sloppy: true */                                                            // 17   // 25
/*global window, navigator, document, importScripts, setTimeout, opera */                                      // 18   // 26
                                                                                                               // 19   // 27
var requirejs, require, define;                                                                                // 20   // 28
(function (global) {                                                                                           // 21   // 29
    var req, s, head, baseElement, dataMain, src,                                                              // 22   // 30
        interactiveScript, currentlyAddingScript, mainScript, subPath,                                         // 23   // 31
        version = '2.1.15',                                                                                    // 24   // 32
        commentRegExp = /(\/\*([\s\S]*?)\*\/|([^:]|^)\/\/(.*)$)/mg,                                            // 25   // 33
        cjsRequireRegExp = /[^.]\s*require\s*\(\s*["']([^'"\s]+)["']\s*\)/g,                                   // 26   // 34
        jsSuffixRegExp = /\.js$/,                                                                              // 27   // 35
        currDirRegExp = /^\.\//,                                                                               // 28   // 36
        op = Object.prototype,                                                                                 // 29   // 37
        ostring = op.toString,                                                                                 // 30   // 38
        hasOwn = op.hasOwnProperty,                                                                            // 31   // 39
        ap = Array.prototype,                                                                                  // 32   // 40
        apsp = ap.splice,                                                                                      // 33   // 41
        isBrowser = !!(typeof window !== 'undefined' && typeof navigator !== 'undefined' && window.document),  // 34   // 42
        isWebWorker = !isBrowser && typeof importScripts !== 'undefined',                                      // 35   // 43
        //PS3 indicates loaded and complete, but need to wait for complete                                     // 36   // 44
        //specifically. Sequence is 'loading', 'loaded', execution,                                            // 37   // 45
        // then 'complete'. The UA check is unfortunate, but not sure how                                      // 38   // 46
        //to feature test w/o causing perf issues.                                                             // 39   // 47
        readyRegExp = isBrowser && navigator.platform === 'PLAYSTATION 3' ?                                    // 40   // 48
                      /^complete$/ : /^(complete|loaded)$/,                                                    // 41   // 49
        defContextName = '_',                                                                                  // 42   // 50
        //Oh the tragedy, detecting opera. See the usage of isOpera for reason.                                // 43   // 51
        isOpera = typeof opera !== 'undefined' && opera.toString() === '[object Opera]',                       // 44   // 52
        contexts = {},                                                                                         // 45   // 53
        cfg = {},                                                                                              // 46   // 54
        globalDefQueue = [],                                                                                   // 47   // 55
        useInteractive = false;                                                                                // 48   // 56
                                                                                                               // 49   // 57
    function isFunction(it) {                                                                                  // 50   // 58
        return ostring.call(it) === '[object Function]';                                                       // 51   // 59
    }                                                                                                          // 52   // 60
                                                                                                               // 53   // 61
    function isArray(it) {                                                                                     // 54   // 62
        return ostring.call(it) === '[object Array]';                                                          // 55   // 63
    }                                                                                                          // 56   // 64
                                                                                                               // 57   // 65
    /**                                                                                                        // 58   // 66
     * Helper function for iterating over an array. If the func returns                                        // 59   // 67
     * a true value, it will break out of the loop.                                                            // 60   // 68
     */                                                                                                        // 61   // 69
    function each(ary, func) {                                                                                 // 62   // 70
        if (ary) {                                                                                             // 63   // 71
            var i;                                                                                             // 64   // 72
            for (i = 0; i < ary.length; i += 1) {                                                              // 65   // 73
                if (ary[i] && func(ary[i], i, ary)) {                                                          // 66   // 74
                    break;                                                                                     // 67   // 75
                }                                                                                              // 68   // 76
            }                                                                                                  // 69   // 77
        }                                                                                                      // 70   // 78
    }                                                                                                          // 71   // 79
                                                                                                               // 72   // 80
    /**                                                                                                        // 73   // 81
     * Helper function for iterating over an array backwards. If the func                                      // 74   // 82
     * returns a true value, it will break out of the loop.                                                    // 75   // 83
     */                                                                                                        // 76   // 84
    function eachReverse(ary, func) {                                                                          // 77   // 85
        if (ary) {                                                                                             // 78   // 86
            var i;                                                                                             // 79   // 87
            for (i = ary.length - 1; i > -1; i -= 1) {                                                         // 80   // 88
                if (ary[i] && func(ary[i], i, ary)) {                                                          // 81   // 89
                    break;                                                                                     // 82   // 90
                }                                                                                              // 83   // 91
            }                                                                                                  // 84   // 92
        }                                                                                                      // 85   // 93
    }                                                                                                          // 86   // 94
                                                                                                               // 87   // 95
    function hasProp(obj, prop) {                                                                              // 88   // 96
        return hasOwn.call(obj, prop);                                                                         // 89   // 97
    }                                                                                                          // 90   // 98
                                                                                                               // 91   // 99
    function getOwn(obj, prop) {                                                                               // 92   // 100
        return hasProp(obj, prop) && obj[prop];                                                                // 93   // 101
    }                                                                                                          // 94   // 102
                                                                                                               // 95   // 103
    /**                                                                                                        // 96   // 104
     * Cycles over properties in an object and calls a function for each                                       // 97   // 105
     * property value. If the function returns a truthy value, then the                                        // 98   // 106
     * iteration is stopped.                                                                                   // 99   // 107
     */                                                                                                        // 100  // 108
    function eachProp(obj, func) {                                                                             // 101  // 109
        var prop;                                                                                              // 102  // 110
        for (prop in obj) {                                                                                    // 103  // 111
            if (hasProp(obj, prop)) {                                                                          // 104  // 112
                if (func(obj[prop], prop)) {                                                                   // 105  // 113
                    break;                                                                                     // 106  // 114
                }                                                                                              // 107  // 115
            }                                                                                                  // 108  // 116
        }                                                                                                      // 109  // 117
    }                                                                                                          // 110  // 118
                                                                                                               // 111  // 119
    /**                                                                                                        // 112  // 120
     * Simple function to mix in properties from source into target,                                           // 113  // 121
     * but only if target does not already have a property of the same name.                                   // 114  // 122
     */                                                                                                        // 115  // 123
    function mixin(target, source, force, deepStringMixin) {                                                   // 116  // 124
        if (source) {                                                                                          // 117  // 125
            eachProp(source, function (value, prop) {                                                          // 118  // 126
                if (force || !hasProp(target, prop)) {                                                         // 119  // 127
                    if (deepStringMixin && typeof value === 'object' && value &&                               // 120  // 128
                        !isArray(value) && !isFunction(value) &&                                               // 121  // 129
                        !(value instanceof RegExp)) {                                                          // 122  // 130
                                                                                                               // 123  // 131
                        if (!target[prop]) {                                                                   // 124  // 132
                            target[prop] = {};                                                                 // 125  // 133
                        }                                                                                      // 126  // 134
                        mixin(target[prop], value, force, deepStringMixin);                                    // 127  // 135
                    } else {                                                                                   // 128  // 136
                        target[prop] = value;                                                                  // 129  // 137
                    }                                                                                          // 130  // 138
                }                                                                                              // 131  // 139
            });                                                                                                // 132  // 140
        }                                                                                                      // 133  // 141
        return target;                                                                                         // 134  // 142
    }                                                                                                          // 135  // 143
                                                                                                               // 136  // 144
    //Similar to Function.prototype.bind, but the 'this' object is specified                                   // 137  // 145
    //first, since it is easier to read/figure out what 'this' will be.                                        // 138  // 146
    function bind(obj, fn) {                                                                                   // 139  // 147
        return function () {                                                                                   // 140  // 148
            return fn.apply(obj, arguments);                                                                   // 141  // 149
        };                                                                                                     // 142  // 150
    }                                                                                                          // 143  // 151
                                                                                                               // 144  // 152
    function scripts() {                                                                                       // 145  // 153
        return document.getElementsByTagName('script');                                                        // 146  // 154
    }                                                                                                          // 147  // 155
                                                                                                               // 148  // 156
    function defaultOnError(err) {                                                                             // 149  // 157
        throw err;                                                                                             // 150  // 158
    }                                                                                                          // 151  // 159
                                                                                                               // 152  // 160
    //Allow getting a global that is expressed in                                                              // 153  // 161
    //dot notation, like 'a.b.c'.                                                                              // 154  // 162
    function getGlobal(value) {                                                                                // 155  // 163
        if (!value) {                                                                                          // 156  // 164
            return value;                                                                                      // 157  // 165
        }                                                                                                      // 158  // 166
        var g = global;                                                                                        // 159  // 167
        each(value.split('.'), function (part) {                                                               // 160  // 168
            g = g[part];                                                                                       // 161  // 169
        });                                                                                                    // 162  // 170
        return g;                                                                                              // 163  // 171
    }                                                                                                          // 164  // 172
                                                                                                               // 165  // 173
    /**                                                                                                        // 166  // 174
     * Constructs an error with a pointer to an URL with more information.                                     // 167  // 175
     * @param {String} id the error ID that maps to an ID on a web page.                                       // 168  // 176
     * @param {String} message human readable error.                                                           // 169  // 177
     * @param {Error} [err] the original error, if there is one.                                               // 170  // 178
     *                                                                                                         // 171  // 179
     * @returns {Error}                                                                                        // 172  // 180
     */                                                                                                        // 173  // 181
    function makeError(id, msg, err, requireModules) {                                                         // 174  // 182
        var e = new Error(msg + '\nhttp://requirejs.org/docs/errors.html#' + id);                              // 175  // 183
        e.requireType = id;                                                                                    // 176  // 184
        e.requireModules = requireModules;                                                                     // 177  // 185
        if (err) {                                                                                             // 178  // 186
            e.originalError = err;                                                                             // 179  // 187
        }                                                                                                      // 180  // 188
        return e;                                                                                              // 181  // 189
    }                                                                                                          // 182  // 190
                                                                                                               // 183  // 191
    if (typeof define !== 'undefined') {                                                                       // 184  // 192
        //If a define is already in play via another AMD loader,                                               // 185  // 193
        //do not overwrite.                                                                                    // 186  // 194
        return;                                                                                                // 187  // 195
    }                                                                                                          // 188  // 196
                                                                                                               // 189  // 197
    if (typeof requirejs !== 'undefined') {                                                                    // 190  // 198
        if (isFunction(requirejs)) {                                                                           // 191  // 199
            //Do not overwrite an existing requirejs instance.                                                 // 192  // 200
            return;                                                                                            // 193  // 201
        }                                                                                                      // 194  // 202
        cfg = requirejs;                                                                                       // 195  // 203
        requirejs = undefined;                                                                                 // 196  // 204
    }                                                                                                          // 197  // 205
                                                                                                               // 198  // 206
    //Allow for a require config object                                                                        // 199  // 207
    if (typeof require !== 'undefined' && !isFunction(require)) {                                              // 200  // 208
        //assume it is a config object.                                                                        // 201  // 209
        cfg = require;                                                                                         // 202  // 210
        require = undefined;                                                                                   // 203  // 211
    }                                                                                                          // 204  // 212
                                                                                                               // 205  // 213
    function newContext(contextName) {                                                                         // 206  // 214
        var inCheckLoaded, Module, context, handlers,                                                          // 207  // 215
            checkLoadedTimeoutId,                                                                              // 208  // 216
            config = {                                                                                         // 209  // 217
                //Defaults. Do not set a default for map                                                       // 210  // 218
                //config to speed up normalize(), which                                                        // 211  // 219
                //will run faster if there is no default.                                                      // 212  // 220
                waitSeconds: 7,                                                                                // 213  // 221
                baseUrl: './',                                                                                 // 214  // 222
                paths: {},                                                                                     // 215  // 223
                bundles: {},                                                                                   // 216  // 224
                pkgs: {},                                                                                      // 217  // 225
                shim: {},                                                                                      // 218  // 226
                config: {}                                                                                     // 219  // 227
            },                                                                                                 // 220  // 228
            registry = {},                                                                                     // 221  // 229
            //registry of just enabled modules, to speed                                                       // 222  // 230
            //cycle breaking code when lots of modules                                                         // 223  // 231
            //are registered, but not activated.                                                               // 224  // 232
            enabledRegistry = {},                                                                              // 225  // 233
            undefEvents = {},                                                                                  // 226  // 234
            defQueue = [],                                                                                     // 227  // 235
            defined = {},                                                                                      // 228  // 236
            urlFetched = {},                                                                                   // 229  // 237
            bundlesMap = {},                                                                                   // 230  // 238
            requireCounter = 1,                                                                                // 231  // 239
            unnormalizedCounter = 1;                                                                           // 232  // 240
                                                                                                               // 233  // 241
        /**                                                                                                    // 234  // 242
         * Trims the . and .. from an array of path segments.                                                  // 235  // 243
         * It will keep a leading path segment if a .. will become                                             // 236  // 244
         * the first path segment, to help with module name lookups,                                           // 237  // 245
         * which act like paths, but can be remapped. But the end result,                                      // 238  // 246
         * all paths that use this function should look normalized.                                            // 239  // 247
         * NOTE: this method MODIFIES the input array.                                                         // 240  // 248
         * @param {Array} ary the array of path segments.                                                      // 241  // 249
         */                                                                                                    // 242  // 250
        function trimDots(ary) {                                                                               // 243  // 251
            var i, part;                                                                                       // 244  // 252
            for (i = 0; i < ary.length; i++) {                                                                 // 245  // 253
                part = ary[i];                                                                                 // 246  // 254
                if (part === '.') {                                                                            // 247  // 255
                    ary.splice(i, 1);                                                                          // 248  // 256
                    i -= 1;                                                                                    // 249  // 257
                } else if (part === '..') {                                                                    // 250  // 258
                    // If at the start, or previous value is still ..,                                         // 251  // 259
                    // keep them so that when converted to a path it may                                       // 252  // 260
                    // still work when converted to a path, even though                                        // 253  // 261
                    // as an ID it is less than ideal. In larger point                                         // 254  // 262
                    // releases, may be better to just kick out an error.                                      // 255  // 263
                    if (i === 0 || (i == 1 && ary[2] === '..') || ary[i - 1] === '..') {                       // 256  // 264
                        continue;                                                                              // 257  // 265
                    } else if (i > 0) {                                                                        // 258  // 266
                        ary.splice(i - 1, 2);                                                                  // 259  // 267
                        i -= 2;                                                                                // 260  // 268
                    }                                                                                          // 261  // 269
                }                                                                                              // 262  // 270
            }                                                                                                  // 263  // 271
        }                                                                                                      // 264  // 272
                                                                                                               // 265  // 273
        /**                                                                                                    // 266  // 274
         * Given a relative module name, like ./something, normalize it to                                     // 267  // 275
         * a real name that can be mapped to a path.                                                           // 268  // 276
         * @param {String} name the relative name                                                              // 269  // 277
         * @param {String} baseName a real name that the name arg is relative                                  // 270  // 278
         * to.                                                                                                 // 271  // 279
         * @param {Boolean} applyMap apply the map config to the value. Should                                 // 272  // 280
         * only be done if this normalization is for a dependency ID.                                          // 273  // 281
         * @returns {String} normalized name                                                                   // 274  // 282
         */                                                                                                    // 275  // 283
        function normalize(name, baseName, applyMap) {                                                         // 276  // 284
            var pkgMain, mapValue, nameParts, i, j, nameSegment, lastIndex,                                    // 277  // 285
                foundMap, foundI, foundStarMap, starI, normalizedBaseParts,                                    // 278  // 286
                baseParts = (baseName && baseName.split('/')),                                                 // 279  // 287
                map = config.map,                                                                              // 280  // 288
                starMap = map && map['*'];                                                                     // 281  // 289
                                                                                                               // 282  // 290
            //Adjust any relative paths.                                                                       // 283  // 291
            if (name) {                                                                                        // 284  // 292
                name = name.split('/');                                                                        // 285  // 293
                lastIndex = name.length - 1;                                                                   // 286  // 294
                                                                                                               // 287  // 295
                // If wanting node ID compatibility, strip .js from end                                        // 288  // 296
                // of IDs. Have to do this here, and not in nameToUrl                                          // 289  // 297
                // because node allows either .js or non .js to map                                            // 290  // 298
                // to same file.                                                                               // 291  // 299
                if (config.nodeIdCompat && jsSuffixRegExp.test(name[lastIndex])) {                             // 292  // 300
                    name[lastIndex] = name[lastIndex].replace(jsSuffixRegExp, '');                             // 293  // 301
                }                                                                                              // 294  // 302
                                                                                                               // 295  // 303
                // Starts with a '.' so need the baseName                                                      // 296  // 304
                if (name[0].charAt(0) === '.' && baseParts) {                                                  // 297  // 305
                    //Convert baseName to array, and lop off the last part,                                    // 298  // 306
                    //so that . matches that 'directory' and not name of the baseName's                        // 299  // 307
                    //module. For instance, baseName of 'one/two/three', maps to                               // 300  // 308
                    //'one/two/three.js', but we want the directory, 'one/two' for                             // 301  // 309
                    //this normalization.                                                                      // 302  // 310
                    normalizedBaseParts = baseParts.slice(0, baseParts.length - 1);                            // 303  // 311
                    name = normalizedBaseParts.concat(name);                                                   // 304  // 312
                }                                                                                              // 305  // 313
                                                                                                               // 306  // 314
                trimDots(name);                                                                                // 307  // 315
                name = name.join('/');                                                                         // 308  // 316
            }                                                                                                  // 309  // 317
                                                                                                               // 310  // 318
            //Apply map config if available.                                                                   // 311  // 319
            if (applyMap && map && (baseParts || starMap)) {                                                   // 312  // 320
                nameParts = name.split('/');                                                                   // 313  // 321
                                                                                                               // 314  // 322
                outerLoop: for (i = nameParts.length; i > 0; i -= 1) {                                         // 315  // 323
                    nameSegment = nameParts.slice(0, i).join('/');                                             // 316  // 324
                                                                                                               // 317  // 325
                    if (baseParts) {                                                                           // 318  // 326
                        //Find the longest baseName segment match in the config.                               // 319  // 327
                        //So, do joins on the biggest to smallest lengths of baseParts.                        // 320  // 328
                        for (j = baseParts.length; j > 0; j -= 1) {                                            // 321  // 329
                            mapValue = getOwn(map, baseParts.slice(0, j).join('/'));                           // 322  // 330
                                                                                                               // 323  // 331
                            //baseName segment has config, find if it has one for                              // 324  // 332
                            //this name.                                                                       // 325  // 333
                            if (mapValue) {                                                                    // 326  // 334
                                mapValue = getOwn(mapValue, nameSegment);                                      // 327  // 335
                                if (mapValue) {                                                                // 328  // 336
                                    //Match, update name to the new value.                                     // 329  // 337
                                    foundMap = mapValue;                                                       // 330  // 338
                                    foundI = i;                                                                // 331  // 339
                                    break outerLoop;                                                           // 332  // 340
                                }                                                                              // 333  // 341
                            }                                                                                  // 334  // 342
                        }                                                                                      // 335  // 343
                    }                                                                                          // 336  // 344
                                                                                                               // 337  // 345
                    //Check for a star map match, but just hold on to it,                                      // 338  // 346
                    //if there is a shorter segment match later in a matching                                  // 339  // 347
                    //config, then favor over this star map.                                                   // 340  // 348
                    if (!foundStarMap && starMap && getOwn(starMap, nameSegment)) {                            // 341  // 349
                        foundStarMap = getOwn(starMap, nameSegment);                                           // 342  // 350
                        starI = i;                                                                             // 343  // 351
                    }                                                                                          // 344  // 352
                }                                                                                              // 345  // 353
                                                                                                               // 346  // 354
                if (!foundMap && foundStarMap) {                                                               // 347  // 355
                    foundMap = foundStarMap;                                                                   // 348  // 356
                    foundI = starI;                                                                            // 349  // 357
                }                                                                                              // 350  // 358
                                                                                                               // 351  // 359
                if (foundMap) {                                                                                // 352  // 360
                    nameParts.splice(0, foundI, foundMap);                                                     // 353  // 361
                    name = nameParts.join('/');                                                                // 354  // 362
                }                                                                                              // 355  // 363
            }                                                                                                  // 356  // 364
                                                                                                               // 357  // 365
            // If the name points to a package's name, use                                                     // 358  // 366
            // the package main instead.                                                                       // 359  // 367
            pkgMain = getOwn(config.pkgs, name);                                                               // 360  // 368
                                                                                                               // 361  // 369
            return pkgMain ? pkgMain : name;                                                                   // 362  // 370
        }                                                                                                      // 363  // 371
                                                                                                               // 364  // 372
        function removeScript(name) {                                                                          // 365  // 373
            if (isBrowser) {                                                                                   // 366  // 374
                each(scripts(), function (scriptNode) {                                                        // 367  // 375
                    if (scriptNode.getAttribute('data-requiremodule') === name &&                              // 368  // 376
                            scriptNode.getAttribute('data-requirecontext') === context.contextName) {          // 369  // 377
                        scriptNode.parentNode.removeChild(scriptNode);                                         // 370  // 378
                        return true;                                                                           // 371  // 379
                    }                                                                                          // 372  // 380
                });                                                                                            // 373  // 381
            }                                                                                                  // 374  // 382
        }                                                                                                      // 375  // 383
                                                                                                               // 376  // 384
        function hasPathFallback(id) {                                                                         // 377  // 385
            var pathConfig = getOwn(config.paths, id);                                                         // 378  // 386
            if (pathConfig && isArray(pathConfig) && pathConfig.length > 1) {                                  // 379  // 387
                //Pop off the first array value, since it failed, and                                          // 380  // 388
                //retry                                                                                        // 381  // 389
                pathConfig.shift();                                                                            // 382  // 390
                context.require.undef(id);                                                                     // 383  // 391
                                                                                                               // 384  // 392
                //Custom require that does not do map translation, since                                       // 385  // 393
                //ID is "absolute", already mapped/resolved.                                                   // 386  // 394
                context.makeRequire(null, {                                                                    // 387  // 395
                    skipMap: true                                                                              // 388  // 396
                })([id]);                                                                                      // 389  // 397
                                                                                                               // 390  // 398
                return true;                                                                                   // 391  // 399
            }                                                                                                  // 392  // 400
        }                                                                                                      // 393  // 401
                                                                                                               // 394  // 402
        //Turns a plugin!resource to [plugin, resource]                                                        // 395  // 403
        //with the plugin being undefined if the name                                                          // 396  // 404
        //did not have a plugin prefix.                                                                        // 397  // 405
        function splitPrefix(name) {                                                                           // 398  // 406
            var prefix,                                                                                        // 399  // 407
                index = name ? name.indexOf('!') : -1;                                                         // 400  // 408
            if (index > -1) {                                                                                  // 401  // 409
                prefix = name.substring(0, index);                                                             // 402  // 410
                name = name.substring(index + 1, name.length);                                                 // 403  // 411
            }                                                                                                  // 404  // 412
            return [prefix, name];                                                                             // 405  // 413
        }                                                                                                      // 406  // 414
                                                                                                               // 407  // 415
        /**                                                                                                    // 408  // 416
         * Creates a module mapping that includes plugin prefix, module                                        // 409  // 417
         * name, and path. If parentModuleMap is provided it will                                              // 410  // 418
         * also normalize the name via require.normalize()                                                     // 411  // 419
         *                                                                                                     // 412  // 420
         * @param {String} name the module name                                                                // 413  // 421
         * @param {String} [parentModuleMap] parent module map                                                 // 414  // 422
         * for the module name, used to resolve relative names.                                                // 415  // 423
         * @param {Boolean} isNormalized: is the ID already normalized.                                        // 416  // 424
         * This is true if this call is done for a define() module ID.                                         // 417  // 425
         * @param {Boolean} applyMap: apply the map config to the ID.                                          // 418  // 426
         * Should only be true if this map is for a dependency.                                                // 419  // 427
         *                                                                                                     // 420  // 428
         * @returns {Object}                                                                                   // 421  // 429
         */                                                                                                    // 422  // 430
        function makeModuleMap(name, parentModuleMap, isNormalized, applyMap) {                                // 423  // 431
            var url, pluginModule, suffix, nameParts,                                                          // 424  // 432
                prefix = null,                                                                                 // 425  // 433
                parentName = parentModuleMap ? parentModuleMap.name : null,                                    // 426  // 434
                originalName = name,                                                                           // 427  // 435
                isDefine = true,                                                                               // 428  // 436
                normalizedName = '';                                                                           // 429  // 437
                                                                                                               // 430  // 438
            //If no name, then it means it is a require call, generate an                                      // 431  // 439
            //internal name.                                                                                   // 432  // 440
            if (!name) {                                                                                       // 433  // 441
                isDefine = false;                                                                              // 434  // 442
                name = '_@r' + (requireCounter += 1);                                                          // 435  // 443
            }                                                                                                  // 436  // 444
                                                                                                               // 437  // 445
            nameParts = splitPrefix(name);                                                                     // 438  // 446
            prefix = nameParts[0];                                                                             // 439  // 447
            name = nameParts[1];                                                                               // 440  // 448
                                                                                                               // 441  // 449
            if (prefix) {                                                                                      // 442  // 450
                prefix = normalize(prefix, parentName, applyMap);                                              // 443  // 451
                pluginModule = getOwn(defined, prefix);                                                        // 444  // 452
            }                                                                                                  // 445  // 453
                                                                                                               // 446  // 454
            //Account for relative paths if there is a base name.                                              // 447  // 455
            if (name) {                                                                                        // 448  // 456
                if (prefix) {                                                                                  // 449  // 457
                    if (pluginModule && pluginModule.normalize) {                                              // 450  // 458
                        //Plugin is loaded, use its normalize method.                                          // 451  // 459
                        normalizedName = pluginModule.normalize(name, function (name) {                        // 452  // 460
                            return normalize(name, parentName, applyMap);                                      // 453  // 461
                        });                                                                                    // 454  // 462
                    } else {                                                                                   // 455  // 463
                        // If nested plugin references, then do not try to                                     // 456  // 464
                        // normalize, as it will not normalize correctly. This                                 // 457  // 465
                        // places a restriction on resourceIds, and the longer                                 // 458  // 466
                        // term solution is not to normalize until plugins are                                 // 459  // 467
                        // loaded and all normalizations to allow for async                                    // 460  // 468
                        // loading of a loader plugin. But for now, fixes the                                  // 461  // 469
                        // common uses. Details in #1131                                                       // 462  // 470
                        normalizedName = name.indexOf('!') === -1 ?                                            // 463  // 471
                                         normalize(name, parentName, applyMap) :                               // 464  // 472
                                         name;                                                                 // 465  // 473
                    }                                                                                          // 466  // 474
                } else {                                                                                       // 467  // 475
                    //A regular module.                                                                        // 468  // 476
                    normalizedName = normalize(name, parentName, applyMap);                                    // 469  // 477
                                                                                                               // 470  // 478
                    //Normalized name may be a plugin ID due to map config                                     // 471  // 479
                    //application in normalize. The map config values must                                     // 472  // 480
                    //already be normalized, so do not need to redo that part.                                 // 473  // 481
                    nameParts = splitPrefix(normalizedName);                                                   // 474  // 482
                    prefix = nameParts[0];                                                                     // 475  // 483
                    normalizedName = nameParts[1];                                                             // 476  // 484
                    isNormalized = true;                                                                       // 477  // 485
                                                                                                               // 478  // 486
                    url = context.nameToUrl(normalizedName);                                                   // 479  // 487
                }                                                                                              // 480  // 488
            }                                                                                                  // 481  // 489
                                                                                                               // 482  // 490
            //If the id is a plugin id that cannot be determined if it needs                                   // 483  // 491
            //normalization, stamp it with a unique ID so two matching relative                                // 484  // 492
            //ids that may conflict can be separate.                                                           // 485  // 493
            suffix = prefix && !pluginModule && !isNormalized ?                                                // 486  // 494
                     '_unnormalized' + (unnormalizedCounter += 1) :                                            // 487  // 495
                     '';                                                                                       // 488  // 496
                                                                                                               // 489  // 497
            return {                                                                                           // 490  // 498
                prefix: prefix,                                                                                // 491  // 499
                name: normalizedName,                                                                          // 492  // 500
                parentMap: parentModuleMap,                                                                    // 493  // 501
                unnormalized: !!suffix,                                                                        // 494  // 502
                url: url,                                                                                      // 495  // 503
                originalName: originalName,                                                                    // 496  // 504
                isDefine: isDefine,                                                                            // 497  // 505
                id: (prefix ?                                                                                  // 498  // 506
                        prefix + '!' + normalizedName :                                                        // 499  // 507
                        normalizedName) + suffix                                                               // 500  // 508
            };                                                                                                 // 501  // 509
        }                                                                                                      // 502  // 510
                                                                                                               // 503  // 511
        function getModule(depMap) {                                                                           // 504  // 512
            var id = depMap.id,                                                                                // 505  // 513
                mod = getOwn(registry, id);                                                                    // 506  // 514
                                                                                                               // 507  // 515
            if (!mod) {                                                                                        // 508  // 516
                mod = registry[id] = new context.Module(depMap);                                               // 509  // 517
            }                                                                                                  // 510  // 518
                                                                                                               // 511  // 519
            return mod;                                                                                        // 512  // 520
        }                                                                                                      // 513  // 521
                                                                                                               // 514  // 522
        function on(depMap, name, fn) {                                                                        // 515  // 523
            var id = depMap.id,                                                                                // 516  // 524
                mod = getOwn(registry, id);                                                                    // 517  // 525
                                                                                                               // 518  // 526
            if (hasProp(defined, id) &&                                                                        // 519  // 527
                    (!mod || mod.defineEmitComplete)) {                                                        // 520  // 528
                if (name === 'defined') {                                                                      // 521  // 529
                    fn(defined[id]);                                                                           // 522  // 530
                }                                                                                              // 523  // 531
            } else {                                                                                           // 524  // 532
                mod = getModule(depMap);                                                                       // 525  // 533
                if (mod.error && name === 'error') {                                                           // 526  // 534
                    fn(mod.error);                                                                             // 527  // 535
                } else {                                                                                       // 528  // 536
                    mod.on(name, fn);                                                                          // 529  // 537
                }                                                                                              // 530  // 538
            }                                                                                                  // 531  // 539
        }                                                                                                      // 532  // 540
                                                                                                               // 533  // 541
        function onError(err, errback) {                                                                       // 534  // 542
            var ids = err.requireModules,                                                                      // 535  // 543
                notified = false;                                                                              // 536  // 544
                                                                                                               // 537  // 545
            if (errback) {                                                                                     // 538  // 546
                errback(err);                                                                                  // 539  // 547
            } else {                                                                                           // 540  // 548
                each(ids, function (id) {                                                                      // 541  // 549
                    var mod = getOwn(registry, id);                                                            // 542  // 550
                    if (mod) {                                                                                 // 543  // 551
                        //Set error on module, so it skips timeout checks.                                     // 544  // 552
                        mod.error = err;                                                                       // 545  // 553
                        if (mod.events.error) {                                                                // 546  // 554
                            notified = true;                                                                   // 547  // 555
                            mod.emit('error', err);                                                            // 548  // 556
                        }                                                                                      // 549  // 557
                    }                                                                                          // 550  // 558
                });                                                                                            // 551  // 559
                                                                                                               // 552  // 560
                if (!notified) {                                                                               // 553  // 561
                    req.onError(err);                                                                          // 554  // 562
                }                                                                                              // 555  // 563
            }                                                                                                  // 556  // 564
        }                                                                                                      // 557  // 565
                                                                                                               // 558  // 566
        /**                                                                                                    // 559  // 567
         * Internal method to transfer globalQueue items to this context's                                     // 560  // 568
         * defQueue.                                                                                           // 561  // 569
         */                                                                                                    // 562  // 570
        function takeGlobalQueue() {                                                                           // 563  // 571
            //Push all the globalDefQueue items into the context's defQueue                                    // 564  // 572
            if (globalDefQueue.length) {                                                                       // 565  // 573
                //Array splice in the values since the context code has a                                      // 566  // 574
                //local var ref to defQueue, so cannot just reassign the one                                   // 567  // 575
                //on context.                                                                                  // 568  // 576
                apsp.apply(defQueue,                                                                           // 569  // 577
                           [defQueue.length, 0].concat(globalDefQueue));                                       // 570  // 578
                globalDefQueue = [];                                                                           // 571  // 579
            }                                                                                                  // 572  // 580
        }                                                                                                      // 573  // 581
                                                                                                               // 574  // 582
        handlers = {                                                                                           // 575  // 583
            'require': function (mod) {                                                                        // 576  // 584
                if (mod.require) {                                                                             // 577  // 585
                    return mod.require;                                                                        // 578  // 586
                } else {                                                                                       // 579  // 587
                    return (mod.require = context.makeRequire(mod.map));                                       // 580  // 588
                }                                                                                              // 581  // 589
            },                                                                                                 // 582  // 590
            'exports': function (mod) {                                                                        // 583  // 591
                mod.usingExports = true;                                                                       // 584  // 592
                if (mod.map.isDefine) {                                                                        // 585  // 593
                    if (mod.exports) {                                                                         // 586  // 594
                        return (defined[mod.map.id] = mod.exports);                                            // 587  // 595
                    } else {                                                                                   // 588  // 596
                        return (mod.exports = defined[mod.map.id] = {});                                       // 589  // 597
                    }                                                                                          // 590  // 598
                }                                                                                              // 591  // 599
            },                                                                                                 // 592  // 600
            'module': function (mod) {                                                                         // 593  // 601
                if (mod.module) {                                                                              // 594  // 602
                    return mod.module;                                                                         // 595  // 603
                } else {                                                                                       // 596  // 604
                    return (mod.module = {                                                                     // 597  // 605
                        id: mod.map.id,                                                                        // 598  // 606
                        uri: mod.map.url,                                                                      // 599  // 607
                        config: function () {                                                                  // 600  // 608
                            return  getOwn(config.config, mod.map.id) || {};                                   // 601  // 609
                        },                                                                                     // 602  // 610
                        exports: mod.exports || (mod.exports = {})                                             // 603  // 611
                    });                                                                                        // 604  // 612
                }                                                                                              // 605  // 613
            }                                                                                                  // 606  // 614
        };                                                                                                     // 607  // 615
                                                                                                               // 608  // 616
        function cleanRegistry(id) {                                                                           // 609  // 617
            //Clean up machinery used for waiting modules.                                                     // 610  // 618
            delete registry[id];                                                                               // 611  // 619
            delete enabledRegistry[id];                                                                        // 612  // 620
        }                                                                                                      // 613  // 621
                                                                                                               // 614  // 622
        function breakCycle(mod, traced, processed) {                                                          // 615  // 623
            var id = mod.map.id;                                                                               // 616  // 624
                                                                                                               // 617  // 625
            if (mod.error) {                                                                                   // 618  // 626
                mod.emit('error', mod.error);                                                                  // 619  // 627
            } else {                                                                                           // 620  // 628
                traced[id] = true;                                                                             // 621  // 629
                each(mod.depMaps, function (depMap, i) {                                                       // 622  // 630
                    var depId = depMap.id,                                                                     // 623  // 631
                        dep = getOwn(registry, depId);                                                         // 624  // 632
                                                                                                               // 625  // 633
                    //Only force things that have not completed                                                // 626  // 634
                    //being defined, so still in the registry,                                                 // 627  // 635
                    //and only if it has not been matched up                                                   // 628  // 636
                    //in the module already.                                                                   // 629  // 637
                    if (dep && !mod.depMatched[i] && !processed[depId]) {                                      // 630  // 638
                        if (getOwn(traced, depId)) {                                                           // 631  // 639
                            mod.defineDep(i, defined[depId]);                                                  // 632  // 640
                            mod.check(); //pass false?                                                         // 633  // 641
                        } else {                                                                               // 634  // 642
                            breakCycle(dep, traced, processed);                                                // 635  // 643
                        }                                                                                      // 636  // 644
                    }                                                                                          // 637  // 645
                });                                                                                            // 638  // 646
                processed[id] = true;                                                                          // 639  // 647
            }                                                                                                  // 640  // 648
        }                                                                                                      // 641  // 649
                                                                                                               // 642  // 650
        function checkLoaded() {                                                                               // 643  // 651
            var err, usingPathFallback,                                                                        // 644  // 652
                waitInterval = config.waitSeconds * 1000,                                                      // 645  // 653
                //It is possible to disable the wait interval by using waitSeconds of 0.                       // 646  // 654
                expired = waitInterval && (context.startTime + waitInterval) < new Date().getTime(),           // 647  // 655
                noLoads = [],                                                                                  // 648  // 656
                reqCalls = [],                                                                                 // 649  // 657
                stillLoading = false,                                                                          // 650  // 658
                needCycleCheck = true;                                                                         // 651  // 659
                                                                                                               // 652  // 660
            //Do not bother if this call was a result of a cycle break.                                        // 653  // 661
            if (inCheckLoaded) {                                                                               // 654  // 662
                return;                                                                                        // 655  // 663
            }                                                                                                  // 656  // 664
                                                                                                               // 657  // 665
            inCheckLoaded = true;                                                                              // 658  // 666
                                                                                                               // 659  // 667
            //Figure out the state of all the modules.                                                         // 660  // 668
            eachProp(enabledRegistry, function (mod) {                                                         // 661  // 669
                var map = mod.map,                                                                             // 662  // 670
                    modId = map.id;                                                                            // 663  // 671
                                                                                                               // 664  // 672
                //Skip things that are not enabled or in error state.                                          // 665  // 673
                if (!mod.enabled) {                                                                            // 666  // 674
                    return;                                                                                    // 667  // 675
                }                                                                                              // 668  // 676
                                                                                                               // 669  // 677
                if (!map.isDefine) {                                                                           // 670  // 678
                    reqCalls.push(mod);                                                                        // 671  // 679
                }                                                                                              // 672  // 680
                                                                                                               // 673  // 681
                if (!mod.error) {                                                                              // 674  // 682
                    //If the module should be executed, and it has not                                         // 675  // 683
                    //been inited and time is up, remember it.                                                 // 676  // 684
                    if (!mod.inited && expired) {                                                              // 677  // 685
                        if (hasPathFallback(modId)) {                                                          // 678  // 686
                            usingPathFallback = true;                                                          // 679  // 687
                            stillLoading = true;                                                               // 680  // 688
                        } else {                                                                               // 681  // 689
                            noLoads.push(modId);                                                               // 682  // 690
                            removeScript(modId);                                                               // 683  // 691
                        }                                                                                      // 684  // 692
                    } else if (!mod.inited && mod.fetched && map.isDefine) {                                   // 685  // 693
                        stillLoading = true;                                                                   // 686  // 694
                        if (!map.prefix) {                                                                     // 687  // 695
                            //No reason to keep looking for unfinished                                         // 688  // 696
                            //loading. If the only stillLoading is a                                           // 689  // 697
                            //plugin resource though, keep going,                                              // 690  // 698
                            //because it may be that a plugin resource                                         // 691  // 699
                            //is waiting on a non-plugin cycle.                                                // 692  // 700
                            return (needCycleCheck = false);                                                   // 693  // 701
                        }                                                                                      // 694  // 702
                    }                                                                                          // 695  // 703
                }                                                                                              // 696  // 704
            });                                                                                                // 697  // 705
                                                                                                               // 698  // 706
            if (expired && noLoads.length) {                                                                   // 699  // 707
                //If wait time expired, throw error of unloaded modules.                                       // 700  // 708
                err = makeError('timeout', 'Load timeout for modules: ' + noLoads, null, noLoads);             // 701  // 709
                err.contextName = context.contextName;                                                         // 702  // 710
                return onError(err);                                                                           // 703  // 711
            }                                                                                                  // 704  // 712
                                                                                                               // 705  // 713
            //Not expired, check for a cycle.                                                                  // 706  // 714
            if (needCycleCheck) {                                                                              // 707  // 715
                each(reqCalls, function (mod) {                                                                // 708  // 716
                    breakCycle(mod, {}, {});                                                                   // 709  // 717
                });                                                                                            // 710  // 718
            }                                                                                                  // 711  // 719
                                                                                                               // 712  // 720
            //If still waiting on loads, and the waiting load is something                                     // 713  // 721
            //other than a plugin resource, or there are still outstanding                                     // 714  // 722
            //scripts, then just try back later.                                                               // 715  // 723
            if ((!expired || usingPathFallback) && stillLoading) {                                             // 716  // 724
                //Something is still waiting to load. Wait for it, but only                                    // 717  // 725
                //if a timeout is not already in effect.                                                       // 718  // 726
                if ((isBrowser || isWebWorker) && !checkLoadedTimeoutId) {                                     // 719  // 727
                    checkLoadedTimeoutId = setTimeout(function () {                                            // 720  // 728
                        checkLoadedTimeoutId = 0;                                                              // 721  // 729
                        checkLoaded();                                                                         // 722  // 730
                    }, 50);                                                                                    // 723  // 731
                }                                                                                              // 724  // 732
            }                                                                                                  // 725  // 733
                                                                                                               // 726  // 734
            inCheckLoaded = false;                                                                             // 727  // 735
        }                                                                                                      // 728  // 736
                                                                                                               // 729  // 737
        Module = function (map) {                                                                              // 730  // 738
            this.events = getOwn(undefEvents, map.id) || {};                                                   // 731  // 739
            this.map = map;                                                                                    // 732  // 740
            this.shim = getOwn(config.shim, map.id);                                                           // 733  // 741
            this.depExports = [];                                                                              // 734  // 742
            this.depMaps = [];                                                                                 // 735  // 743
            this.depMatched = [];                                                                              // 736  // 744
            this.pluginMaps = {};                                                                              // 737  // 745
            this.depCount = 0;                                                                                 // 738  // 746
                                                                                                               // 739  // 747
            /* this.exports this.factory                                                                       // 740  // 748
               this.depMaps = [],                                                                              // 741  // 749
               this.enabled, this.fetched                                                                      // 742  // 750
            */                                                                                                 // 743  // 751
        };                                                                                                     // 744  // 752
                                                                                                               // 745  // 753
        Module.prototype = {                                                                                   // 746  // 754
            init: function (depMaps, factory, errback, options) {                                              // 747  // 755
                options = options || {};                                                                       // 748  // 756
                                                                                                               // 749  // 757
                //Do not do more inits if already done. Can happen if there                                    // 750  // 758
                //are multiple define calls for the same module. That is not                                   // 751  // 759
                //a normal, common case, but it is also not unexpected.                                        // 752  // 760
                if (this.inited) {                                                                             // 753  // 761
                    return;                                                                                    // 754  // 762
                }                                                                                              // 755  // 763
                                                                                                               // 756  // 764
                this.factory = factory;                                                                        // 757  // 765
                                                                                                               // 758  // 766
                if (errback) {                                                                                 // 759  // 767
                    //Register for errors on this module.                                                      // 760  // 768
                    this.on('error', errback);                                                                 // 761  // 769
                } else if (this.events.error) {                                                                // 762  // 770
                    //If no errback already, but there are error listeners                                     // 763  // 771
                    //on this module, set up an errback to pass to the deps.                                   // 764  // 772
                    errback = bind(this, function (err) {                                                      // 765  // 773
                        this.emit('error', err);                                                               // 766  // 774
                    });                                                                                        // 767  // 775
                }                                                                                              // 768  // 776
                                                                                                               // 769  // 777
                //Do a copy of the dependency array, so that                                                   // 770  // 778
                //source inputs are not modified. For example                                                  // 771  // 779
                //"shim" deps are passed in here directly, and                                                 // 772  // 780
                //doing a direct modification of the depMaps array                                             // 773  // 781
                //would affect that config.                                                                    // 774  // 782
                this.depMaps = depMaps && depMaps.slice(0);                                                    // 775  // 783
                                                                                                               // 776  // 784
                this.errback = errback;                                                                        // 777  // 785
                                                                                                               // 778  // 786
                //Indicate this module has be initialized                                                      // 779  // 787
                this.inited = true;                                                                            // 780  // 788
                                                                                                               // 781  // 789
                this.ignore = options.ignore;                                                                  // 782  // 790
                                                                                                               // 783  // 791
                //Could have option to init this module in enabled mode,                                       // 784  // 792
                //or could have been previously marked as enabled. However,                                    // 785  // 793
                //the dependencies are not known until init is called. So                                      // 786  // 794
                //if enabled previously, now trigger dependencies as enabled.                                  // 787  // 795
                if (options.enabled || this.enabled) {                                                         // 788  // 796
                    //Enable this module and dependencies.                                                     // 789  // 797
                    //Will call this.check()                                                                   // 790  // 798
                    this.enable();                                                                             // 791  // 799
                } else {                                                                                       // 792  // 800
                    this.check();                                                                              // 793  // 801
                }                                                                                              // 794  // 802
            },                                                                                                 // 795  // 803
                                                                                                               // 796  // 804
            defineDep: function (i, depExports) {                                                              // 797  // 805
                //Because of cycles, defined callback for a given                                              // 798  // 806
                //export can be called more than once.                                                         // 799  // 807
                if (!this.depMatched[i]) {                                                                     // 800  // 808
                    this.depMatched[i] = true;                                                                 // 801  // 809
                    this.depCount -= 1;                                                                        // 802  // 810
                    this.depExports[i] = depExports;                                                           // 803  // 811
                }                                                                                              // 804  // 812
            },                                                                                                 // 805  // 813
                                                                                                               // 806  // 814
            fetch: function () {                                                                               // 807  // 815
                if (this.fetched) {                                                                            // 808  // 816
                    return;                                                                                    // 809  // 817
                }                                                                                              // 810  // 818
                this.fetched = true;                                                                           // 811  // 819
                                                                                                               // 812  // 820
                context.startTime = (new Date()).getTime();                                                    // 813  // 821
                                                                                                               // 814  // 822
                var map = this.map;                                                                            // 815  // 823
                                                                                                               // 816  // 824
                //If the manager is for a plugin managed resource,                                             // 817  // 825
                //ask the plugin to load it now.                                                               // 818  // 826
                if (this.shim) {                                                                               // 819  // 827
                    context.makeRequire(this.map, {                                                            // 820  // 828
                        enableBuildCallback: true                                                              // 821  // 829
                    })(this.shim.deps || [], bind(this, function () {                                          // 822  // 830
                        return map.prefix ? this.callPlugin() : this.load();                                   // 823  // 831
                    }));                                                                                       // 824  // 832
                } else {                                                                                       // 825  // 833
                    //Regular dependency.                                                                      // 826  // 834
                    return map.prefix ? this.callPlugin() : this.load();                                       // 827  // 835
                }                                                                                              // 828  // 836
            },                                                                                                 // 829  // 837
                                                                                                               // 830  // 838
            load: function () {                                                                                // 831  // 839
                var url = this.map.url;                                                                        // 832  // 840
                                                                                                               // 833  // 841
                //Regular dependency.                                                                          // 834  // 842
                if (!urlFetched[url]) {                                                                        // 835  // 843
                    urlFetched[url] = true;                                                                    // 836  // 844
                    context.load(this.map.id, url);                                                            // 837  // 845
                }                                                                                              // 838  // 846
            },                                                                                                 // 839  // 847
                                                                                                               // 840  // 848
            /**                                                                                                // 841  // 849
             * Checks if the module is ready to define itself, and if so,                                      // 842  // 850
             * define it.                                                                                      // 843  // 851
             */                                                                                                // 844  // 852
            check: function () {                                                                               // 845  // 853
                if (!this.enabled || this.enabling) {                                                          // 846  // 854
                    return;                                                                                    // 847  // 855
                }                                                                                              // 848  // 856
                                                                                                               // 849  // 857
                var err, cjsModule,                                                                            // 850  // 858
                    id = this.map.id,                                                                          // 851  // 859
                    depExports = this.depExports,                                                              // 852  // 860
                    exports = this.exports,                                                                    // 853  // 861
                    factory = this.factory;                                                                    // 854  // 862
                                                                                                               // 855  // 863
                if (!this.inited) {                                                                            // 856  // 864
                    this.fetch();                                                                              // 857  // 865
                } else if (this.error) {                                                                       // 858  // 866
                    this.emit('error', this.error);                                                            // 859  // 867
                } else if (!this.defining) {                                                                   // 860  // 868
                    //The factory could trigger another require call                                           // 861  // 869
                    //that would result in checking this module to                                             // 862  // 870
                    //define itself again. If already in the process                                           // 863  // 871
                    //of doing that, skip this work.                                                           // 864  // 872
                    this.defining = true;                                                                      // 865  // 873
                                                                                                               // 866  // 874
                    if (this.depCount < 1 && !this.defined) {                                                  // 867  // 875
                        if (isFunction(factory)) {                                                             // 868  // 876
                            //If there is an error listener, favor passing                                     // 869  // 877
                            //to that instead of throwing an error. However,                                   // 870  // 878
                            //only do it for define()'d  modules. require                                      // 871  // 879
                            //errbacks should not be called for failures in                                    // 872  // 880
                            //their callbacks (#699). However if a global                                      // 873  // 881
                            //onError is set, use that.                                                        // 874  // 882
                            if ((this.events.error && this.map.isDefine) ||                                    // 875  // 883
                                req.onError !== defaultOnError) {                                              // 876  // 884
                                try {                                                                          // 877  // 885
                                    exports = context.execCb(id, factory, depExports, exports);                // 878  // 886
                                } catch (e) {                                                                  // 879  // 887
                                    err = e;                                                                   // 880  // 888
                                }                                                                              // 881  // 889
                            } else {                                                                           // 882  // 890
                                exports = context.execCb(id, factory, depExports, exports);                    // 883  // 891
                            }                                                                                  // 884  // 892
                                                                                                               // 885  // 893
                            // Favor return value over exports. If node/cjs in play,                           // 886  // 894
                            // then will not have a return value anyway. Favor                                 // 887  // 895
                            // module.exports assignment over exports object.                                  // 888  // 896
                            if (this.map.isDefine && exports === undefined) {                                  // 889  // 897
                                cjsModule = this.module;                                                       // 890  // 898
                                if (cjsModule) {                                                               // 891  // 899
                                    exports = cjsModule.exports;                                               // 892  // 900
                                } else if (this.usingExports) {                                                // 893  // 901
                                    //exports already set the defined value.                                   // 894  // 902
                                    exports = this.exports;                                                    // 895  // 903
                                }                                                                              // 896  // 904
                            }                                                                                  // 897  // 905
                                                                                                               // 898  // 906
                            if (err) {                                                                         // 899  // 907
                                err.requireMap = this.map;                                                     // 900  // 908
                                err.requireModules = this.map.isDefine ? [this.map.id] : null;                 // 901  // 909
                                err.requireType = this.map.isDefine ? 'define' : 'require';                    // 902  // 910
                                return onError((this.error = err));                                            // 903  // 911
                            }                                                                                  // 904  // 912
                                                                                                               // 905  // 913
                        } else {                                                                               // 906  // 914
                            //Just a literal value                                                             // 907  // 915
                            exports = factory;                                                                 // 908  // 916
                        }                                                                                      // 909  // 917
                                                                                                               // 910  // 918
                        this.exports = exports;                                                                // 911  // 919
                                                                                                               // 912  // 920
                        if (this.map.isDefine && !this.ignore) {                                               // 913  // 921
                            defined[id] = exports;                                                             // 914  // 922
                                                                                                               // 915  // 923
                            if (req.onResourceLoad) {                                                          // 916  // 924
                                req.onResourceLoad(context, this.map, this.depMaps);                           // 917  // 925
                            }                                                                                  // 918  // 926
                        }                                                                                      // 919  // 927
                                                                                                               // 920  // 928
                        //Clean up                                                                             // 921  // 929
                        cleanRegistry(id);                                                                     // 922  // 930
                                                                                                               // 923  // 931
                        this.defined = true;                                                                   // 924  // 932
                    }                                                                                          // 925  // 933
                                                                                                               // 926  // 934
                    //Finished the define stage. Allow calling check again                                     // 927  // 935
                    //to allow define notifications below in the case of a                                     // 928  // 936
                    //cycle.                                                                                   // 929  // 937
                    this.defining = false;                                                                     // 930  // 938
                                                                                                               // 931  // 939
                    if (this.defined && !this.defineEmitted) {                                                 // 932  // 940
                        this.defineEmitted = true;                                                             // 933  // 941
                        this.emit('defined', this.exports);                                                    // 934  // 942
                        this.defineEmitComplete = true;                                                        // 935  // 943
                    }                                                                                          // 936  // 944
                                                                                                               // 937  // 945
                }                                                                                              // 938  // 946
            },                                                                                                 // 939  // 947
                                                                                                               // 940  // 948
            callPlugin: function () {                                                                          // 941  // 949
                var map = this.map,                                                                            // 942  // 950
                    id = map.id,                                                                               // 943  // 951
                    //Map already normalized the prefix.                                                       // 944  // 952
                    pluginMap = makeModuleMap(map.prefix);                                                     // 945  // 953
                                                                                                               // 946  // 954
                //Mark this as a dependency for this plugin, so it                                             // 947  // 955
                //can be traced for cycles.                                                                    // 948  // 956
                this.depMaps.push(pluginMap);                                                                  // 949  // 957
                                                                                                               // 950  // 958
                on(pluginMap, 'defined', bind(this, function (plugin) {                                        // 951  // 959
                    var load, normalizedMap, normalizedMod,                                                    // 952  // 960
                        bundleId = getOwn(bundlesMap, this.map.id),                                            // 953  // 961
                        name = this.map.name,                                                                  // 954  // 962
                        parentName = this.map.parentMap ? this.map.parentMap.name : null,                      // 955  // 963
                        localRequire = context.makeRequire(map.parentMap, {                                    // 956  // 964
                            enableBuildCallback: true                                                          // 957  // 965
                        });                                                                                    // 958  // 966
                                                                                                               // 959  // 967
                    //If current map is not normalized, wait for that                                          // 960  // 968
                    //normalized name to load instead of continuing.                                           // 961  // 969
                    if (this.map.unnormalized) {                                                               // 962  // 970
                        //Normalize the ID if the plugin allows it.                                            // 963  // 971
                        if (plugin.normalize) {                                                                // 964  // 972
                            name = plugin.normalize(name, function (name) {                                    // 965  // 973
                                return normalize(name, parentName, true);                                      // 966  // 974
                            }) || '';                                                                          // 967  // 975
                        }                                                                                      // 968  // 976
                                                                                                               // 969  // 977
                        //prefix and name should already be normalized, no need                                // 970  // 978
                        //for applying map config again either.                                                // 971  // 979
                        normalizedMap = makeModuleMap(map.prefix + '!' + name,                                 // 972  // 980
                                                      this.map.parentMap);                                     // 973  // 981
                        on(normalizedMap,                                                                      // 974  // 982
                            'defined', bind(this, function (value) {                                           // 975  // 983
                                this.init([], function () { return value; }, null, {                           // 976  // 984
                                    enabled: true,                                                             // 977  // 985
                                    ignore: true                                                               // 978  // 986
                                });                                                                            // 979  // 987
                            }));                                                                               // 980  // 988
                                                                                                               // 981  // 989
                        normalizedMod = getOwn(registry, normalizedMap.id);                                    // 982  // 990
                        if (normalizedMod) {                                                                   // 983  // 991
                            //Mark this as a dependency for this plugin, so it                                 // 984  // 992
                            //can be traced for cycles.                                                        // 985  // 993
                            this.depMaps.push(normalizedMap);                                                  // 986  // 994
                                                                                                               // 987  // 995
                            if (this.events.error) {                                                           // 988  // 996
                                normalizedMod.on('error', bind(this, function (err) {                          // 989  // 997
                                    this.emit('error', err);                                                   // 990  // 998
                                }));                                                                           // 991  // 999
                            }                                                                                  // 992  // 1000
                            normalizedMod.enable();                                                            // 993  // 1001
                        }                                                                                      // 994  // 1002
                                                                                                               // 995  // 1003
                        return;                                                                                // 996  // 1004
                    }                                                                                          // 997  // 1005
                                                                                                               // 998  // 1006
                    //If a paths config, then just load that file instead to                                   // 999  // 1007
                    //resolve the plugin, as it is built into that paths layer.                                // 1000
                    if (bundleId) {                                                                            // 1001
                        this.map.url = context.nameToUrl(bundleId);                                            // 1002
                        this.load();                                                                           // 1003
                        return;                                                                                // 1004
                    }                                                                                          // 1005
                                                                                                               // 1006
                    load = bind(this, function (value) {                                                       // 1007
                        this.init([], function () { return value; }, null, {                                   // 1008
                            enabled: true                                                                      // 1009
                        });                                                                                    // 1010
                    });                                                                                        // 1011
                                                                                                               // 1012
                    load.error = bind(this, function (err) {                                                   // 1013
                        this.inited = true;                                                                    // 1014
                        this.error = err;                                                                      // 1015
                        err.requireModules = [id];                                                             // 1016
                                                                                                               // 1017
                        //Remove temp unnormalized modules for this module,                                    // 1018
                        //since they will never be resolved otherwise now.                                     // 1019
                        eachProp(registry, function (mod) {                                                    // 1020
                            if (mod.map.id.indexOf(id + '_unnormalized') === 0) {                              // 1021
                                cleanRegistry(mod.map.id);                                                     // 1022
                            }                                                                                  // 1023
                        });                                                                                    // 1024
                                                                                                               // 1025
                        onError(err);                                                                          // 1026
                    });                                                                                        // 1027
                                                                                                               // 1028
                    //Allow plugins to load other code without having to know the                              // 1029
                    //context or how to 'complete' the load.                                                   // 1030
                    load.fromText = bind(this, function (text, textAlt) {                                      // 1031
                        /*jslint evil: true */                                                                 // 1032
                        var moduleName = map.name,                                                             // 1033
                            moduleMap = makeModuleMap(moduleName),                                             // 1034
                            hasInteractive = useInteractive;                                                   // 1035
                                                                                                               // 1036
                        //As of 2.1.0, support just passing the text, to reinforce                             // 1037
                        //fromText only being called once per resource. Still                                  // 1038
                        //support old style of passing moduleName but discard                                  // 1039
                        //that moduleName in favor of the internal ref.                                        // 1040
                        if (textAlt) {                                                                         // 1041
                            text = textAlt;                                                                    // 1042
                        }                                                                                      // 1043
                                                                                                               // 1044
                        //Turn off interactive script matching for IE for any define                           // 1045
                        //calls in the text, then turn it back on at the end.                                  // 1046
                        if (hasInteractive) {                                                                  // 1047
                            useInteractive = false;                                                            // 1048
                        }                                                                                      // 1049
                                                                                                               // 1050
                        //Prime the system by creating a module instance for                                   // 1051
                        //it.                                                                                  // 1052
                        getModule(moduleMap);                                                                  // 1053
                                                                                                               // 1054
                        //Transfer any config to this other module.                                            // 1055
                        if (hasProp(config.config, id)) {                                                      // 1056
                            config.config[moduleName] = config.config[id];                                     // 1057
                        }                                                                                      // 1058
                                                                                                               // 1059
                        try {                                                                                  // 1060
                            req.exec(text);                                                                    // 1061
                        } catch (e) {                                                                          // 1062
                            return onError(makeError('fromtexteval',                                           // 1063
                                             'fromText eval for ' + id +                                       // 1064
                                            ' failed: ' + e,                                                   // 1065
                                             e,                                                                // 1066
                                             [id]));                                                           // 1067
                        }                                                                                      // 1068
                                                                                                               // 1069
                        if (hasInteractive) {                                                                  // 1070
                            useInteractive = true;                                                             // 1071
                        }                                                                                      // 1072
                                                                                                               // 1073
                        //Mark this as a dependency for the plugin                                             // 1074
                        //resource                                                                             // 1075
                        this.depMaps.push(moduleMap);                                                          // 1076
                                                                                                               // 1077
                        //Support anonymous modules.                                                           // 1078
                        context.completeLoad(moduleName);                                                      // 1079
                                                                                                               // 1080
                        //Bind the value of that module to the value for this                                  // 1081
                        //resource ID.                                                                         // 1082
                        localRequire([moduleName], load);                                                      // 1083
                    });                                                                                        // 1084
                                                                                                               // 1085
                    //Use parentName here since the plugin's name is not reliable,                             // 1086
                    //could be some weird string with no path that actually wants to                           // 1087
                    //reference the parentName's path.                                                         // 1088
                    plugin.load(map.name, localRequire, load, config);                                         // 1089
                }));                                                                                           // 1090
                                                                                                               // 1091
                context.enable(pluginMap, this);                                                               // 1092
                this.pluginMaps[pluginMap.id] = pluginMap;                                                     // 1093
            },                                                                                                 // 1094
                                                                                                               // 1095
            enable: function () {                                                                              // 1096
                enabledRegistry[this.map.id] = this;                                                           // 1097
                this.enabled = true;                                                                           // 1098
                                                                                                               // 1099
                //Set flag mentioning that the module is enabling,                                             // 1100
                //so that immediate calls to the defined callbacks                                             // 1101
                //for dependencies do not trigger inadvertent load                                             // 1102
                //with the depCount still being zero.                                                          // 1103
                this.enabling = true;                                                                          // 1104
                                                                                                               // 1105
                //Enable each dependency                                                                       // 1106
                each(this.depMaps, bind(this, function (depMap, i) {                                           // 1107
                    var id, mod, handler;                                                                      // 1108
                                                                                                               // 1109
                    if (typeof depMap === 'string') {                                                          // 1110
                        //Dependency needs to be converted to a depMap                                         // 1111
                        //and wired up to this module.                                                         // 1112
                        depMap = makeModuleMap(depMap,                                                         // 1113
                                               (this.map.isDefine ? this.map : this.map.parentMap),            // 1114
                                               false,                                                          // 1115
                                               !this.skipMap);                                                 // 1116
                        this.depMaps[i] = depMap;                                                              // 1117
                                                                                                               // 1118
                        handler = getOwn(handlers, depMap.id);                                                 // 1119
                                                                                                               // 1120
                        if (handler) {                                                                         // 1121
                            this.depExports[i] = handler(this);                                                // 1122
                            return;                                                                            // 1123
                        }                                                                                      // 1124
                                                                                                               // 1125
                        this.depCount += 1;                                                                    // 1126
                                                                                                               // 1127
                        on(depMap, 'defined', bind(this, function (depExports) {                               // 1128
                            this.defineDep(i, depExports);                                                     // 1129
                            this.check();                                                                      // 1130
                        }));                                                                                   // 1131
                                                                                                               // 1132
                        if (this.errback) {                                                                    // 1133
                            on(depMap, 'error', bind(this, this.errback));                                     // 1134
                        }                                                                                      // 1135
                    }                                                                                          // 1136
                                                                                                               // 1137
                    id = depMap.id;                                                                            // 1138
                    mod = registry[id];                                                                        // 1139
                                                                                                               // 1140
                    //Skip special modules like 'require', 'exports', 'module'                                 // 1141
                    //Also, don't call enable if it is already enabled,                                        // 1142
                    //important in circular dependency cases.                                                  // 1143
                    if (!hasProp(handlers, id) && mod && !mod.enabled) {                                       // 1144
                        context.enable(depMap, this);                                                          // 1145
                    }                                                                                          // 1146
                }));                                                                                           // 1147
                                                                                                               // 1148
                //Enable each plugin that is used in                                                           // 1149
                //a dependency                                                                                 // 1150
                eachProp(this.pluginMaps, bind(this, function (pluginMap) {                                    // 1151
                    var mod = getOwn(registry, pluginMap.id);                                                  // 1152
                    if (mod && !mod.enabled) {                                                                 // 1153
                        context.enable(pluginMap, this);                                                       // 1154
                    }                                                                                          // 1155
                }));                                                                                           // 1156
                                                                                                               // 1157
                this.enabling = false;                                                                         // 1158
                                                                                                               // 1159
                this.check();                                                                                  // 1160
            },                                                                                                 // 1161
                                                                                                               // 1162
            on: function (name, cb) {                                                                          // 1163
                var cbs = this.events[name];                                                                   // 1164
                if (!cbs) {                                                                                    // 1165
                    cbs = this.events[name] = [];                                                              // 1166
                }                                                                                              // 1167
                cbs.push(cb);                                                                                  // 1168
            },                                                                                                 // 1169
                                                                                                               // 1170
            emit: function (name, evt) {                                                                       // 1171
                each(this.events[name], function (cb) {                                                        // 1172
                    cb(evt);                                                                                   // 1173
                });                                                                                            // 1174
                if (name === 'error') {                                                                        // 1175
                    //Now that the error handler was triggered, remove                                         // 1176
                    //the listeners, since this broken Module instance                                         // 1177
                    //can stay around for a while in the registry.                                             // 1178
                    delete this.events[name];                                                                  // 1179
                }                                                                                              // 1180
            }                                                                                                  // 1181
        };                                                                                                     // 1182
                                                                                                               // 1183
        function callGetModule(args) {                                                                         // 1184
            //Skip modules already defined.                                                                    // 1185
            if (!hasProp(defined, args[0])) {                                                                  // 1186
                getModule(makeModuleMap(args[0], null, true)).init(args[1], args[2]);                          // 1187
            }                                                                                                  // 1188
        }                                                                                                      // 1189
                                                                                                               // 1190
        function removeListener(node, func, name, ieName) {                                                    // 1191
            //Favor detachEvent because of IE9                                                                 // 1192
            //issue, see attachEvent/addEventListener comment elsewhere                                        // 1193
            //in this file.                                                                                    // 1194
            if (node.detachEvent && !isOpera) {                                                                // 1195
                //Probably IE. If not it will throw an error, which will be                                    // 1196
                //useful to know.                                                                              // 1197
                if (ieName) {                                                                                  // 1198
                    node.detachEvent(ieName, func);                                                            // 1199
                }                                                                                              // 1200
            } else {                                                                                           // 1201
                node.removeEventListener(name, func, false);                                                   // 1202
            }                                                                                                  // 1203
        }                                                                                                      // 1204
                                                                                                               // 1205
        /**                                                                                                    // 1206
         * Given an event from a script node, get the requirejs info from it,                                  // 1207
         * and then removes the event listeners on the node.                                                   // 1208
         * @param {Event} evt                                                                                  // 1209
         * @returns {Object}                                                                                   // 1210
         */                                                                                                    // 1211
        function getScriptData(evt) {                                                                          // 1212
            //Using currentTarget instead of target for Firefox 2.0's sake. Not                                // 1213
            //all old browsers will be supported, but this one was easy enough                                 // 1214
            //to support and still makes sense.                                                                // 1215
            var node = evt.currentTarget || evt.srcElement;                                                    // 1216
                                                                                                               // 1217
            //Remove the listeners once here.                                                                  // 1218
            removeListener(node, context.onScriptLoad, 'load', 'onreadystatechange');                          // 1219
            removeListener(node, context.onScriptError, 'error');                                              // 1220
                                                                                                               // 1221
            return {                                                                                           // 1222
                node: node,                                                                                    // 1223
                id: node && node.getAttribute('data-requiremodule')                                            // 1224
            };                                                                                                 // 1225
        }                                                                                                      // 1226
                                                                                                               // 1227
        function intakeDefines() {                                                                             // 1228
            var args;                                                                                          // 1229
                                                                                                               // 1230
            //Any defined modules in the global queue, intake them now.                                        // 1231
            takeGlobalQueue();                                                                                 // 1232
                                                                                                               // 1233
            //Make sure any remaining defQueue items get properly processed.                                   // 1234
            while (defQueue.length) {                                                                          // 1235
                args = defQueue.shift();                                                                       // 1236
                if (args[0] === null) {                                                                        // 1237
                    var msg = 'Mismatched anonymous define() module: ' + args[args.length - 1];                // 1238
                    if (typeof Meteor !== 'undefined') {                                                       // 1239
                        // Meteor packages are loaded in script tags and should not be defined                 // 1240
                        // unless a module ID is provided. Show a warning at most.                             // 1241
                        console.warn(msg);                                                                     // 1242
                        return;                                                                                // 1243
                    } else {                                                                                   // 1244
                        return onError(makeError('mismatch', msg));                                            // 1245
                    }                                                                                          // 1246
                } else {                                                                                       // 1247
                    //args are id, deps, factory. Should be normalized by the                                  // 1248
                    //define() function.                                                                       // 1249
                    callGetModule(args);                                                                       // 1250
                }                                                                                              // 1251
            }                                                                                                  // 1252
        }                                                                                                      // 1253
                                                                                                               // 1254
        context = {                                                                                            // 1255
            config: config,                                                                                    // 1256
            contextName: contextName,                                                                          // 1257
            registry: registry,                                                                                // 1258
            defined: defined,                                                                                  // 1259
            urlFetched: urlFetched,                                                                            // 1260
            defQueue: defQueue,                                                                                // 1261
            Module: Module,                                                                                    // 1262
            makeModuleMap: makeModuleMap,                                                                      // 1263
            nextTick: req.nextTick,                                                                            // 1264
            onError: onError,                                                                                  // 1265
                                                                                                               // 1266
            /**                                                                                                // 1267
             * Set a configuration for the context.                                                            // 1268
             * @param {Object} cfg config object to integrate.                                                 // 1269
             */                                                                                                // 1270
            configure: function (cfg) {                                                                        // 1271
                //Make sure the baseUrl ends in a slash.                                                       // 1272
                if (cfg.baseUrl) {                                                                             // 1273
                    if (cfg.baseUrl.charAt(cfg.baseUrl.length - 1) !== '/') {                                  // 1274
                        cfg.baseUrl += '/';                                                                    // 1275
                    }                                                                                          // 1276
                }                                                                                              // 1277
                                                                                                               // 1278
                //Save off the paths since they require special processing,                                    // 1279
                //they are additive.                                                                           // 1280
                var shim = config.shim,                                                                        // 1281
                    objs = {                                                                                   // 1282
                        paths: true,                                                                           // 1283
                        bundles: true,                                                                         // 1284
                        config: true,                                                                          // 1285
                        map: true                                                                              // 1286
                    };                                                                                         // 1287
                                                                                                               // 1288
                eachProp(cfg, function (value, prop) {                                                         // 1289
                    if (objs[prop]) {                                                                          // 1290
                        if (!config[prop]) {                                                                   // 1291
                            config[prop] = {};                                                                 // 1292
                        }                                                                                      // 1293
                        mixin(config[prop], value, true, true);                                                // 1294
                    } else {                                                                                   // 1295
                        config[prop] = value;                                                                  // 1296
                    }                                                                                          // 1297
                });                                                                                            // 1298
                                                                                                               // 1299
                //Reverse map the bundles                                                                      // 1300
                if (cfg.bundles) {                                                                             // 1301
                    eachProp(cfg.bundles, function (value, prop) {                                             // 1302
                        each(value, function (v) {                                                             // 1303
                            if (v !== prop) {                                                                  // 1304
                                bundlesMap[v] = prop;                                                          // 1305
                            }                                                                                  // 1306
                        });                                                                                    // 1307
                    });                                                                                        // 1308
                }                                                                                              // 1309
                                                                                                               // 1310
                //Merge shim                                                                                   // 1311
                if (cfg.shim) {                                                                                // 1312
                    eachProp(cfg.shim, function (value, id) {                                                  // 1313
                        //Normalize the structure                                                              // 1314
                        if (isArray(value)) {                                                                  // 1315
                            value = {                                                                          // 1316
                                deps: value                                                                    // 1317
                            };                                                                                 // 1318
                        }                                                                                      // 1319
                        if ((value.exports || value.init) && !value.exportsFn) {                               // 1320
                            value.exportsFn = context.makeShimExports(value);                                  // 1321
                        }                                                                                      // 1322
                        shim[id] = value;                                                                      // 1323
                    });                                                                                        // 1324
                    config.shim = shim;                                                                        // 1325
                }                                                                                              // 1326
                                                                                                               // 1327
                //Adjust packages if necessary.                                                                // 1328
                if (cfg.packages) {                                                                            // 1329
                    each(cfg.packages, function (pkgObj) {                                                     // 1330
                        var location, name;                                                                    // 1331
                                                                                                               // 1332
                        pkgObj = typeof pkgObj === 'string' ? { name: pkgObj } : pkgObj;                       // 1333
                                                                                                               // 1334
                        name = pkgObj.name;                                                                    // 1335
                        location = pkgObj.location;                                                            // 1336
                        if (location) {                                                                        // 1337
                            config.paths[name] = pkgObj.location;                                              // 1338
                        }                                                                                      // 1339
                                                                                                               // 1340
                        //Save pointer to main module ID for pkg name.                                         // 1341
                        //Remove leading dot in main, so main paths are normalized,                            // 1342
                        //and remove any trailing .js, since different package                                 // 1343
                        //envs have different conventions: some use a module name,                             // 1344
                        //some use a file name.                                                                // 1345
                        config.pkgs[name] = pkgObj.name + '/' + (pkgObj.main || 'main')                        // 1346
                                     .replace(currDirRegExp, '')                                               // 1347
                                     .replace(jsSuffixRegExp, '');                                             // 1348
                    });                                                                                        // 1349
                }                                                                                              // 1350
                                                                                                               // 1351
                //If there are any "waiting to execute" modules in the registry,                               // 1352
                //update the maps for them, since their info, like URLs to load,                               // 1353
                //may have changed.                                                                            // 1354
                eachProp(registry, function (mod, id) {                                                        // 1355
                    //If module already has init called, since it is too                                       // 1356
                    //late to modify them, and ignore unnormalized ones                                        // 1357
                    //since they are transient.                                                                // 1358
                    if (!mod.inited && !mod.map.unnormalized) {                                                // 1359
                        mod.map = makeModuleMap(id);                                                           // 1360
                    }                                                                                          // 1361
                });                                                                                            // 1362
                                                                                                               // 1363
                //If a deps array or a config callback is specified, then call                                 // 1364
                //require with those args. This is useful when require is defined as a                         // 1365
                //config object before require.js is loaded.                                                   // 1366
                if (cfg.deps || cfg.callback) {                                                                // 1367
                    context.require(cfg.deps || [], cfg.callback);                                             // 1368
                }                                                                                              // 1369
            },                                                                                                 // 1370
                                                                                                               // 1371
            makeShimExports: function (value) {                                                                // 1372
                function fn() {                                                                                // 1373
                    var ret;                                                                                   // 1374
                    if (value.init) {                                                                          // 1375
                        ret = value.init.apply(global, arguments);                                             // 1376
                    }                                                                                          // 1377
                    return ret || (value.exports && getGlobal(value.exports));                                 // 1378
                }                                                                                              // 1379
                return fn;                                                                                     // 1380
            },                                                                                                 // 1381
                                                                                                               // 1382
            makeRequire: function (relMap, options) {                                                          // 1383
                options = options || {};                                                                       // 1384
                                                                                                               // 1385
                function localRequire(deps, callback, errback) {                                               // 1386
                    var id, map, requireMod;                                                                   // 1387
                                                                                                               // 1388
                    if (options.enableBuildCallback && callback && isFunction(callback)) {                     // 1389
                        callback.__requireJsBuild = true;                                                      // 1390
                    }                                                                                          // 1391
                                                                                                               // 1392
                    if (typeof deps === 'string') {                                                            // 1393
                        if (isFunction(callback)) {                                                            // 1394
                            //Invalid call                                                                     // 1395
                            return onError(makeError('requireargs', 'Invalid require call'), errback);         // 1396
                        }                                                                                      // 1397
                                                                                                               // 1398
                        //If require|exports|module are requested, get the                                     // 1399
                        //value for them from the special handlers. Caveat:                                    // 1400
                        //this only works while module is being defined.                                       // 1401
                        if (relMap && hasProp(handlers, deps)) {                                               // 1402
                            return handlers[deps](registry[relMap.id]);                                        // 1403
                        }                                                                                      // 1404
                                                                                                               // 1405
                        //Synchronous access to one module. If require.get is                                  // 1406
                        //available (as in the Node adapter), prefer that.                                     // 1407
                        if (req.get) {                                                                         // 1408
                            return req.get(context, deps, relMap, localRequire);                               // 1409
                        }                                                                                      // 1410
                                                                                                               // 1411
                        //Normalize module name, if it contains . or ..                                        // 1412
                        map = makeModuleMap(deps, relMap, false, true);                                        // 1413
                        id = map.id;                                                                           // 1414
                                                                                                               // 1415
                        if (!hasProp(defined, id)) {                                                           // 1416
                            return onError(makeError('notloaded', 'Module name "' +                            // 1417
                                        id +                                                                   // 1418
                                        '" has not been loaded yet for context: ' +                            // 1419
                                        contextName +                                                          // 1420
                                        (relMap ? '' : '. Use require([])')));                                 // 1421
                        }                                                                                      // 1422
                        return defined[id];                                                                    // 1423
                    }                                                                                          // 1424
                                                                                                               // 1425
                    //Grab defines waiting in the global queue.                                                // 1426
                    intakeDefines();                                                                           // 1427
                                                                                                               // 1428
                    //Mark all the dependencies as needing to be loaded.                                       // 1429
                    context.nextTick(function () {                                                             // 1430
                        //Some defines could have been added since the                                         // 1431
                        //require call, collect them.                                                          // 1432
                        intakeDefines();                                                                       // 1433
                                                                                                               // 1434
                        requireMod = getModule(makeModuleMap(null, relMap));                                   // 1435
                                                                                                               // 1436
                        //Store if map config should be applied to this require                                // 1437
                        //call for dependencies.                                                               // 1438
                        requireMod.skipMap = options.skipMap;                                                  // 1439
                                                                                                               // 1440
                        requireMod.init(deps, callback, errback, {                                             // 1441
                            enabled: true                                                                      // 1442
                        });                                                                                    // 1443
                                                                                                               // 1444
                        checkLoaded();                                                                         // 1445
                    });                                                                                        // 1446
                                                                                                               // 1447
                    return localRequire;                                                                       // 1448
                }                                                                                              // 1449
                                                                                                               // 1450
                mixin(localRequire, {                                                                          // 1451
                    isBrowser: isBrowser,                                                                      // 1452
                                                                                                               // 1453
                    /**                                                                                        // 1454
                     * Converts a module name + .extension into an URL path.                                   // 1455
                     * *Requires* the use of a module name. It does not support using                          // 1456
                     * plain URLs like nameToUrl.                                                              // 1457
                     */                                                                                        // 1458
                    toUrl: function (moduleNamePlusExt) {                                                      // 1459
                        var ext,                                                                               // 1460
                            index = moduleNamePlusExt.lastIndexOf('.'),                                        // 1461
                            segment = moduleNamePlusExt.split('/')[0],                                         // 1462
                            isRelative = segment === '.' || segment === '..';                                  // 1463
                                                                                                               // 1464
                        //Have a file extension alias, and it is not the                                       // 1465
                        //dots from a relative path.                                                           // 1466
                        if (index !== -1 && (!isRelative || index > 1)) {                                      // 1467
                            ext = moduleNamePlusExt.substring(index, moduleNamePlusExt.length);                // 1468
                            moduleNamePlusExt = moduleNamePlusExt.substring(0, index);                         // 1469
                        }                                                                                      // 1470
                                                                                                               // 1471
                        return context.nameToUrl(normalize(moduleNamePlusExt,                                  // 1472
                                                relMap && relMap.id, true), ext,  true);                       // 1473
                    },                                                                                         // 1474
                                                                                                               // 1475
                    defined: function (id) {                                                                   // 1476
                        return hasProp(defined, makeModuleMap(id, relMap, false, true).id);                    // 1477
                    },                                                                                         // 1478
                                                                                                               // 1479
                    specified: function (id) {                                                                 // 1480
                        id = makeModuleMap(id, relMap, false, true).id;                                        // 1481
                        return hasProp(defined, id) || hasProp(registry, id);                                  // 1482
                    }                                                                                          // 1483
                });                                                                                            // 1484
                                                                                                               // 1485
                //Only allow undef on top level require calls                                                  // 1486
                if (!relMap) {                                                                                 // 1487
                    localRequire.undef = function (id) {                                                       // 1488
                        //Bind any waiting define() calls to this context,                                     // 1489
                        //fix for #408                                                                         // 1490
                        takeGlobalQueue();                                                                     // 1491
                                                                                                               // 1492
                        var map = makeModuleMap(id, relMap, true),                                             // 1493
                            mod = getOwn(registry, id);                                                        // 1494
                                                                                                               // 1495
                        removeScript(id);                                                                      // 1496
                                                                                                               // 1497
                        delete defined[id];                                                                    // 1498
                        delete urlFetched[map.url];                                                            // 1499
                        delete undefEvents[id];                                                                // 1500
                                                                                                               // 1501
                        //Clean queued defines too. Go backwards                                               // 1502
                        //in array so that the splices do not                                                  // 1503
                        //mess up the iteration.                                                               // 1504
                        eachReverse(defQueue, function(args, i) {                                              // 1505
                            if(args[0] === id) {                                                               // 1506
                                defQueue.splice(i, 1);                                                         // 1507
                            }                                                                                  // 1508
                        });                                                                                    // 1509
                                                                                                               // 1510
                        if (mod) {                                                                             // 1511
                            //Hold on to listeners in case the                                                 // 1512
                            //module will be attempted to be reloaded                                          // 1513
                            //using a different config.                                                        // 1514
                            if (mod.events.defined) {                                                          // 1515
                                undefEvents[id] = mod.events;                                                  // 1516
                            }                                                                                  // 1517
                                                                                                               // 1518
                            cleanRegistry(id);                                                                 // 1519
                        }                                                                                      // 1520
                    };                                                                                         // 1521
                }                                                                                              // 1522
                                                                                                               // 1523
                return localRequire;                                                                           // 1524
            },                                                                                                 // 1525
                                                                                                               // 1526
            /**                                                                                                // 1527
             * Called to enable a module if it is still in the registry                                        // 1528
             * awaiting enablement. A second arg, parent, the parent module,                                   // 1529
             * is passed in for context, when this method is overridden by                                     // 1530
             * the optimizer. Not shown here to keep code compact.                                             // 1531
             */                                                                                                // 1532
            enable: function (depMap) {                                                                        // 1533
                var mod = getOwn(registry, depMap.id);                                                         // 1534
                if (mod) {                                                                                     // 1535
                    getModule(depMap).enable();                                                                // 1536
                }                                                                                              // 1537
            },                                                                                                 // 1538
                                                                                                               // 1539
            /**                                                                                                // 1540
             * Internal method used by environment adapters to complete a load event.                          // 1541
             * A load event could be a script load or just a load pass from a synchronous                      // 1542
             * load call.                                                                                      // 1543
             * @param {String} moduleName the name of the module to potentially complete.                      // 1544
             */                                                                                                // 1545
            completeLoad: function (moduleName) {                                                              // 1546
                var found, args, mod,                                                                          // 1547
                    shim = getOwn(config.shim, moduleName) || {},                                              // 1548
                    shExports = shim.exports;                                                                  // 1549
                                                                                                               // 1550
                takeGlobalQueue();                                                                             // 1551
                                                                                                               // 1552
                while (defQueue.length) {                                                                      // 1553
                    args = defQueue.shift();                                                                   // 1554
                    if (args[0] === null) {                                                                    // 1555
                        args[0] = moduleName;                                                                  // 1556
                        //If already found an anonymous module and bound it                                    // 1557
                        //to this name, then this is some other anon module                                    // 1558
                        //waiting for its completeLoad to fire.                                                // 1559
                        if (found) {                                                                           // 1560
                            break;                                                                             // 1561
                        }                                                                                      // 1562
                        found = true;                                                                          // 1563
                    } else if (args[0] === moduleName) {                                                       // 1564
                        //Found matching define call for this script!                                          // 1565
                        found = true;                                                                          // 1566
                    }                                                                                          // 1567
                                                                                                               // 1568
                    callGetModule(args);                                                                       // 1569
                }                                                                                              // 1570
                                                                                                               // 1571
                //Do this after the cycle of callGetModule in case the result                                  // 1572
                //of those calls/init calls changes the registry.                                              // 1573
                mod = getOwn(registry, moduleName);                                                            // 1574
                                                                                                               // 1575
                if (!found && !hasProp(defined, moduleName) && mod && !mod.inited) {                           // 1576
                    if (config.enforceDefine && (!shExports || !getGlobal(shExports))) {                       // 1577
                        if (hasPathFallback(moduleName)) {                                                     // 1578
                            return;                                                                            // 1579
                        } else {                                                                               // 1580
                            return onError(makeError('nodefine',                                               // 1581
                                             'No define call for ' + moduleName,                               // 1582
                                             null,                                                             // 1583
                                             [moduleName]));                                                   // 1584
                        }                                                                                      // 1585
                    } else {                                                                                   // 1586
                        //A script that does not call define(), so just simulate                               // 1587
                        //the call for it.                                                                     // 1588
                        callGetModule([moduleName, (shim.deps || []), shim.exportsFn]);                        // 1589
                    }                                                                                          // 1590
                }                                                                                              // 1591
                                                                                                               // 1592
                checkLoaded();                                                                                 // 1593
            },                                                                                                 // 1594
                                                                                                               // 1595
            /**                                                                                                // 1596
             * Converts a module name to a file path. Supports cases where                                     // 1597
             * moduleName may actually be just an URL.                                                         // 1598
             * Note that it **does not** call normalize on the moduleName,                                     // 1599
             * it is assumed to have already been normalized. This is an                                       // 1600
             * internal API, not a public one. Use toUrl for the public API.                                   // 1601
             */                                                                                                // 1602
            nameToUrl: function (moduleName, ext, skipExt) {                                                   // 1603
                var paths, syms, i, parentModule, url,                                                         // 1604
                    parentPath, bundleId,                                                                      // 1605
                    pkgMain = getOwn(config.pkgs, moduleName);                                                 // 1606
                                                                                                               // 1607
                if (pkgMain) {                                                                                 // 1608
                    moduleName = pkgMain;                                                                      // 1609
                }                                                                                              // 1610
                                                                                                               // 1611
                bundleId = getOwn(bundlesMap, moduleName);                                                     // 1612
                                                                                                               // 1613
                if (bundleId) {                                                                                // 1614
                    return context.nameToUrl(bundleId, ext, skipExt);                                          // 1615
                }                                                                                              // 1616
                                                                                                               // 1617
                //If a colon is in the URL, it indicates a protocol is used and it is just                     // 1618
                //an URL to a file, or if it starts with a slash, contains a query arg (i.e. ?)                // 1619
                //or ends with .js, then assume the user meant to use an url and not a module id.              // 1620
                //The slash is important for protocol-less URLs as well as full paths.                         // 1621
                if (req.jsExtRegExp.test(moduleName)) {                                                        // 1622
                    //Just a plain path, not module name lookup, so just return it.                            // 1623
                    //Add extension if it is included. This is a bit wonky, only non-.js things pass           // 1624
                    //an extension, this method probably needs to be reworked.                                 // 1625
                    url = moduleName + (ext || '');                                                            // 1626
                } else {                                                                                       // 1627
                    //A module that needs to be converted to a path.                                           // 1628
                    paths = config.paths;                                                                      // 1629
                                                                                                               // 1630
                    syms = moduleName.split('/');                                                              // 1631
                    //For each module name segment, see if there is a path                                     // 1632
                    //registered for it. Start with most specific name                                         // 1633
                    //and work up from it.                                                                     // 1634
                    for (i = syms.length; i > 0; i -= 1) {                                                     // 1635
                        parentModule = syms.slice(0, i).join('/');                                             // 1636
                                                                                                               // 1637
                        parentPath = getOwn(paths, parentModule);                                              // 1638
                        if (parentPath) {                                                                      // 1639
                            //If an array, it means there are a few choices,                                   // 1640
                            //Choose the one that is desired                                                   // 1641
                            if (isArray(parentPath)) {                                                         // 1642
                                parentPath = parentPath[0];                                                    // 1643
                            }                                                                                  // 1644
                            syms.splice(0, i, parentPath);                                                     // 1645
                            break;                                                                             // 1646
                        }                                                                                      // 1647
                    }                                                                                          // 1648
                                                                                                               // 1649
                    //Join the path parts together, then figure out if baseUrl is needed.                      // 1650
                    url = syms.join('/');                                                                      // 1651
                    url += (ext || (/^data\:|\?/.test(url) || skipExt ? '' : '.js'));                          // 1652
                    url = (url.charAt(0) === '/' || url.match(/^[\w\+\.\-]+:/) ? '' : config.baseUrl) + url;   // 1653
                }                                                                                              // 1654
                                                                                                               // 1655
                return config.urlArgs ? url +                                                                  // 1656
                                        ((url.indexOf('?') === -1 ? '?' : '&') +                               // 1657
                                         config.urlArgs) : url;                                                // 1658
            },                                                                                                 // 1659
                                                                                                               // 1660
            //Delegates to req.load. Broken out as a separate function to                                      // 1661
            //allow overriding in the optimizer.                                                               // 1662
            load: function (id, url) {                                                                         // 1663
                req.load(context, id, url);                                                                    // 1664
            },                                                                                                 // 1665
                                                                                                               // 1666
            /**                                                                                                // 1667
             * Executes a module callback function. Broken out as a separate function                          // 1668
             * solely to allow the build system to sequence the files in the built                             // 1669
             * layer in the right sequence.                                                                    // 1670
             *                                                                                                 // 1671
             * @private                                                                                        // 1672
             */                                                                                                // 1673
            execCb: function (name, callback, args, exports) {                                                 // 1674
                return callback.apply(exports, args);                                                          // 1675
            },                                                                                                 // 1676
                                                                                                               // 1677
            /**                                                                                                // 1678
             * callback for script loads, used to check status of loading.                                     // 1679
             *                                                                                                 // 1680
             * @param {Event} evt the event from the browser for the script                                    // 1681
             * that was loaded.                                                                                // 1682
             */                                                                                                // 1683
            onScriptLoad: function (evt) {                                                                     // 1684
                //Using currentTarget instead of target for Firefox 2.0's sake. Not                            // 1685
                //all old browsers will be supported, but this one was easy enough                             // 1686
                //to support and still makes sense.                                                            // 1687
                if (evt.type === 'load' ||                                                                     // 1688
                        (readyRegExp.test((evt.currentTarget || evt.srcElement).readyState))) {                // 1689
                    //Reset interactive script so a script node is not held onto for                           // 1690
                    //to long.                                                                                 // 1691
                    interactiveScript = null;                                                                  // 1692
                                                                                                               // 1693
                    //Pull out the name of the module and the context.                                         // 1694
                    var data = getScriptData(evt);                                                             // 1695
                    context.completeLoad(data.id);                                                             // 1696
                }                                                                                              // 1697
            },                                                                                                 // 1698
                                                                                                               // 1699
            /**                                                                                                // 1700
             * Callback for script errors.                                                                     // 1701
             */                                                                                                // 1702
            onScriptError: function (evt) {                                                                    // 1703
                var data = getScriptData(evt);                                                                 // 1704
                if (!hasPathFallback(data.id)) {                                                               // 1705
                    return onError(makeError('scripterror', 'Script error for: ' + data.id, evt, [data.id]));  // 1706
                }                                                                                              // 1707
            }                                                                                                  // 1708
        };                                                                                                     // 1709
                                                                                                               // 1710
        context.require = context.makeRequire();                                                               // 1711
        return context;                                                                                        // 1712
    }                                                                                                          // 1713
                                                                                                               // 1714
    /**                                                                                                        // 1715
     * Main entry point.                                                                                       // 1716
     *                                                                                                         // 1717
     * If the only argument to require is a string, then the module that                                       // 1718
     * is represented by that string is fetched for the appropriate context.                                   // 1719
     *                                                                                                         // 1720
     * If the first argument is an array, then it will be treated as an array                                  // 1721
     * of dependency string names to fetch. An optional function callback can                                  // 1722
     * be specified to execute when all of those dependencies are available.                                   // 1723
     *                                                                                                         // 1724
     * Make a local req variable to help Caja compliance (it assumes things                                    // 1725
     * on a require that are not standardized), and to give a short                                            // 1726
     * name for minification/local scope use.                                                                  // 1727
     */                                                                                                        // 1728
    req = requirejs = function (deps, callback, errback, optional) {                                           // 1729
                                                                                                               // 1730
        //Find the right context, use default                                                                  // 1731
        var context, config,                                                                                   // 1732
            contextName = defContextName;                                                                      // 1733
                                                                                                               // 1734
        // Determine if have config object in the call.                                                        // 1735
        if (!isArray(deps) && typeof deps !== 'string') {                                                      // 1736
            // deps is a config object                                                                         // 1737
            config = deps;                                                                                     // 1738
            if (isArray(callback)) {                                                                           // 1739
                // Adjust args if there are dependencies                                                       // 1740
                deps = callback;                                                                               // 1741
                callback = errback;                                                                            // 1742
                errback = optional;                                                                            // 1743
            } else {                                                                                           // 1744
                deps = [];                                                                                     // 1745
            }                                                                                                  // 1746
        }                                                                                                      // 1747
                                                                                                               // 1748
        if (config && config.context) {                                                                        // 1749
            contextName = config.context;                                                                      // 1750
        }                                                                                                      // 1751
                                                                                                               // 1752
        context = getOwn(contexts, contextName);                                                               // 1753
        if (!context) {                                                                                        // 1754
            context = contexts[contextName] = req.s.newContext(contextName);                                   // 1755
        }                                                                                                      // 1756
                                                                                                               // 1757
        if (config) {                                                                                          // 1758
            context.configure(config);                                                                         // 1759
        }                                                                                                      // 1760
                                                                                                               // 1761
        return context.require(deps, callback, errback);                                                       // 1762
    };                                                                                                         // 1763
                                                                                                               // 1764
    /**                                                                                                        // 1765
     * Support require.config() to make it easier to cooperate with other                                      // 1766
     * AMD loaders on globally agreed names.                                                                   // 1767
     */                                                                                                        // 1768
    req.config = function (config) {                                                                           // 1769
        return req(config);                                                                                    // 1770
    };                                                                                                         // 1771
                                                                                                               // 1772
    /**                                                                                                        // 1773
     * Execute something after the current tick                                                                // 1774
     * of the event loop. Override for other envs                                                              // 1775
     * that have a better solution than setTimeout.                                                            // 1776
     * @param  {Function} fn function to execute later.                                                        // 1777
     */                                                                                                        // 1778
    req.nextTick = typeof setTimeout !== 'undefined' ? function (fn) {                                         // 1779
        setTimeout(fn, 4);                                                                                     // 1780
    } : function (fn) { fn(); };                                                                               // 1781
                                                                                                               // 1782
    /**                                                                                                        // 1783
     * Export require as a global, but only if it does not already exist.                                      // 1784
     */                                                                                                        // 1785
    if (!require) {                                                                                            // 1786
        require = req;                                                                                         // 1787
    }                                                                                                          // 1788
                                                                                                               // 1789
    req.version = version;                                                                                     // 1790
                                                                                                               // 1791
    //Used to filter out dependencies that are already paths.                                                  // 1792
    req.jsExtRegExp = /^\/|:|\?|\.js$/;                                                                        // 1793
    req.isBrowser = isBrowser;                                                                                 // 1794
    s = req.s = {                                                                                              // 1795
        contexts: contexts,                                                                                    // 1796
        newContext: newContext                                                                                 // 1797
    };                                                                                                         // 1798
                                                                                                               // 1799
    //Create default context.                                                                                  // 1800
    req({});                                                                                                   // 1801
                                                                                                               // 1802
    //Exports some context-sensitive methods on global require.                                                // 1803
    each([                                                                                                     // 1804
        'toUrl',                                                                                               // 1805
        'undef',                                                                                               // 1806
        'defined',                                                                                             // 1807
        'specified'                                                                                            // 1808
    ], function (prop) {                                                                                       // 1809
        //Reference from contexts instead of early binding to default context,                                 // 1810
        //so that during builds, the latest instance of the default context                                    // 1811
        //with its config gets used.                                                                           // 1812
        req[prop] = function () {                                                                              // 1813
            var ctx = contexts[defContextName];                                                                // 1814
            return ctx.require[prop].apply(ctx, arguments);                                                    // 1815
        };                                                                                                     // 1816
    });                                                                                                        // 1817
                                                                                                               // 1818
    if (isBrowser) {                                                                                           // 1819
        head = s.head = document.getElementsByTagName('head')[0];                                              // 1820
        //If BASE tag is in play, using appendChild is a problem for IE6.                                      // 1821
        //When that browser dies, this can be removed. Details in this jQuery bug:                             // 1822
        //http://dev.jquery.com/ticket/2709                                                                    // 1823
        baseElement = document.getElementsByTagName('base')[0];                                                // 1824
        if (baseElement) {                                                                                     // 1825
            head = s.head = baseElement.parentNode;                                                            // 1826
        }                                                                                                      // 1827
    }                                                                                                          // 1828
                                                                                                               // 1829
    /**                                                                                                        // 1830
     * Any errors that require explicitly generates will be passed to this                                     // 1831
     * function. Intercept/override it if you want custom error handling.                                      // 1832
     * @param {Error} err the error object.                                                                    // 1833
     */                                                                                                        // 1834
    req.onError = defaultOnError;                                                                              // 1835
                                                                                                               // 1836
    /**                                                                                                        // 1837
     * Creates the node for the load command. Only used in browser envs.                                       // 1838
     */                                                                                                        // 1839
    req.createNode = function (config, moduleName, url) {                                                      // 1840
        var node = config.xhtml ?                                                                              // 1841
                document.createElementNS('http://www.w3.org/1999/xhtml', 'html:script') :                      // 1842
                document.createElement('script');                                                              // 1843
        node.type = config.scriptType || 'text/javascript';                                                    // 1844
        node.charset = 'utf-8';                                                                                // 1845
        node.async = true;                                                                                     // 1846
        return node;                                                                                           // 1847
    };                                                                                                         // 1848
                                                                                                               // 1849
    /**                                                                                                        // 1850
     * Does the request to load a module for the browser case.                                                 // 1851
     * Make this a separate function to allow other environments                                               // 1852
     * to override it.                                                                                         // 1853
     *                                                                                                         // 1854
     * @param {Object} context the require context to find state.                                              // 1855
     * @param {String} moduleName the name of the module.                                                      // 1856
     * @param {Object} url the URL to the module.                                                              // 1857
     */                                                                                                        // 1858
    req.load = function (context, moduleName, url) {                                                           // 1859
        var config = (context && context.config) || {},                                                        // 1860
            node;                                                                                              // 1861
        if (isBrowser) {                                                                                       // 1862
            //In the browser so use a script tag                                                               // 1863
            node = req.createNode(config, moduleName, url);                                                    // 1864
                                                                                                               // 1865
            node.setAttribute('data-requirecontext', context.contextName);                                     // 1866
            node.setAttribute('data-requiremodule', moduleName);                                               // 1867
                                                                                                               // 1868
            //Set up load listener. Test attachEvent first because IE9 has                                     // 1869
            //a subtle issue in its addEventListener and script onload firings                                 // 1870
            //that do not match the behavior of all other browsers with                                        // 1871
            //addEventListener support, which fire the onload event for a                                      // 1872
            //script right after the script execution. See:                                                    // 1873
            //https://connect.microsoft.com/IE/feedback/details/648057/script-onload-event-is-not-fired-immediately-after-script-execution
            //UNFORTUNATELY Opera implements attachEvent but does not follow the script                        // 1875
            //script execution mode.                                                                           // 1876
            if (node.attachEvent &&                                                                            // 1877
                    //Check if node.attachEvent is artificially added by custom script or                      // 1878
                    //natively supported by browser                                                            // 1879
                    //read https://github.com/jrburke/requirejs/issues/187                                     // 1880
                    //if we can NOT find [native code] then it must NOT natively supported.                    // 1881
                    //in IE8, node.attachEvent does not have toString()                                        // 1882
                    //Note the test for "[native code" with no closing brace, see:                             // 1883
                    //https://github.com/jrburke/requirejs/issues/273                                          // 1884
                    !(node.attachEvent.toString && node.attachEvent.toString().indexOf('[native code') < 0) && // 1885
                    !isOpera) {                                                                                // 1886
                //Probably IE. IE (at least 6-8) do not fire                                                   // 1887
                //script onload right after executing the script, so                                           // 1888
                //we cannot tie the anonymous define call to a name.                                           // 1889
                //However, IE reports the script as being in 'interactive'                                     // 1890
                //readyState at the time of the define call.                                                   // 1891
                useInteractive = true;                                                                         // 1892
                                                                                                               // 1893
                node.attachEvent('onreadystatechange', context.onScriptLoad);                                  // 1894
                //It would be great to add an error handler here to catch                                      // 1895
                //404s in IE9+. However, onreadystatechange will fire before                                   // 1896
                //the error handler, so that does not help. If addEventListener                                // 1897
                //is used, then IE will fire error before load, but we cannot                                  // 1898
                //use that pathway given the connect.microsoft.com issue                                       // 1899
                //mentioned above about not doing the 'script execute,                                         // 1900
                //then fire the script load event listener before execute                                      // 1901
                //next script' that other browsers do.                                                         // 1902
                //Best hope: IE10 fixes the issues,                                                            // 1903
                //and then destroys all installs of IE 6-9.                                                    // 1904
                //node.attachEvent('onerror', context.onScriptError);                                          // 1905
            } else {                                                                                           // 1906
                node.addEventListener('load', context.onScriptLoad, false);                                    // 1907
                node.addEventListener('error', context.onScriptError, false);                                  // 1908
            }                                                                                                  // 1909
            node.src = url;                                                                                    // 1910
                                                                                                               // 1911
            //For some cache cases in IE 6-8, the script executes before the end                               // 1912
            //of the appendChild execution, so to tie an anonymous define                                      // 1913
            //call to the module name (which is stored on the node), hold on                                   // 1914
            //to a reference to this node, but clear after the DOM insertion.                                  // 1915
            currentlyAddingScript = node;                                                                      // 1916
            if (baseElement) {                                                                                 // 1917
                head.insertBefore(node, baseElement);                                                          // 1918
            } else {                                                                                           // 1919
                head.appendChild(node);                                                                        // 1920
            }                                                                                                  // 1921
            currentlyAddingScript = null;                                                                      // 1922
                                                                                                               // 1923
            return node;                                                                                       // 1924
        } else if (isWebWorker) {                                                                              // 1925
            try {                                                                                              // 1926
                //In a web worker, use importScripts. This is not a very                                       // 1927
                //efficient use of importScripts, importScripts will block until                               // 1928
                //its script is downloaded and evaluated. However, if web workers                              // 1929
                //are in play, the expectation that a build has been done so that                              // 1930
                //only one script needs to be loaded anyway. This may need to be                               // 1931
                //reevaluated if other use cases become common.                                                // 1932
                importScripts(url);                                                                            // 1933
                                                                                                               // 1934
                //Account for anonymous modules                                                                // 1935
                context.completeLoad(moduleName);                                                              // 1936
            } catch (e) {                                                                                      // 1937
                context.onError(makeError('importscripts',                                                     // 1938
                                'importScripts failed for ' +                                                  // 1939
                                    moduleName + ' at ' + url,                                                 // 1940
                                e,                                                                             // 1941
                                [moduleName]));                                                                // 1942
            }                                                                                                  // 1943
        }                                                                                                      // 1944
    };                                                                                                         // 1945
                                                                                                               // 1946
    function getInteractiveScript() {                                                                          // 1947
        if (interactiveScript && interactiveScript.readyState === 'interactive') {                             // 1948
            return interactiveScript;                                                                          // 1949
        }                                                                                                      // 1950
                                                                                                               // 1951
        eachReverse(scripts(), function (script) {                                                             // 1952
            if (script.readyState === 'interactive') {                                                         // 1953
                return (interactiveScript = script);                                                           // 1954
            }                                                                                                  // 1955
        });                                                                                                    // 1956
        return interactiveScript;                                                                              // 1957
    }                                                                                                          // 1958
                                                                                                               // 1959
    //Look for a data-main script attribute, which could also adjust the baseUrl.                              // 1960
    if (isBrowser && !cfg.skipDataMain) {                                                                      // 1961
        //Figure out baseUrl. Get it from the script tag with require.js in it.                                // 1962
        eachReverse(scripts(), function (script) {                                                             // 1963
            //Set the 'head' where we can append children by                                                   // 1964
            //using the script's parent.                                                                       // 1965
            if (!head) {                                                                                       // 1966
                head = script.parentNode;                                                                      // 1967
            }                                                                                                  // 1968
                                                                                                               // 1969
            //Look for a data-main attribute to set main script for the page                                   // 1970
            //to load. If it is there, the path to data main becomes the                                       // 1971
            //baseUrl, if it is not already set.                                                               // 1972
            dataMain = script.getAttribute('data-main');                                                       // 1973
            if (dataMain) {                                                                                    // 1974
                //Preserve dataMain in case it is a path (i.e. contains '?')                                   // 1975
                mainScript = dataMain;                                                                         // 1976
                                                                                                               // 1977
                //Set final baseUrl if there is not already an explicit one.                                   // 1978
                if (!cfg.baseUrl) {                                                                            // 1979
                    //Pull off the directory of data-main for use as the                                       // 1980
                    //baseUrl.                                                                                 // 1981
                    src = mainScript.split('/');                                                               // 1982
                    mainScript = src.pop();                                                                    // 1983
                    subPath = src.length ? src.join('/')  + '/' : './';                                        // 1984
                                                                                                               // 1985
                    cfg.baseUrl = subPath;                                                                     // 1986
                }                                                                                              // 1987
                                                                                                               // 1988
                //Strip off any trailing .js since mainScript is now                                           // 1989
                //like a module name.                                                                          // 1990
                mainScript = mainScript.replace(jsSuffixRegExp, '');                                           // 1991
                                                                                                               // 1992
                 //If mainScript is still a path, fall back to dataMain                                        // 1993
                if (req.jsExtRegExp.test(mainScript)) {                                                        // 1994
                    mainScript = dataMain;                                                                     // 1995
                }                                                                                              // 1996
                                                                                                               // 1997
                //Put the data-main script in the files to load.                                               // 1998
                cfg.deps = cfg.deps ? cfg.deps.concat(mainScript) : [mainScript];                              // 1999
                                                                                                               // 2000
                return true;                                                                                   // 2001
            }                                                                                                  // 2002
        });                                                                                                    // 2003
    }                                                                                                          // 2004
                                                                                                               // 2005
    /**                                                                                                        // 2006
     * The function that handles definitions of modules. Differs from                                          // 2007
     * require() in that a string for the module should be the first argument,                                 // 2008
     * and the function to execute after dependencies are loaded should                                        // 2009
     * return a value to define the module corresponding to the first argument's                               // 2010
     * name.                                                                                                   // 2011
     */                                                                                                        // 2012
    define = function (name, deps, callback) {                                                                 // 2013
        var node, context;                                                                                     // 2014
                                                                                                               // 2015
        //Allow for anonymous modules                                                                          // 2016
        if (typeof name !== 'string') {                                                                        // 2017
            //Adjust args appropriately                                                                        // 2018
            callback = deps;                                                                                   // 2019
            deps = name;                                                                                       // 2020
            name = null;                                                                                       // 2021
        }                                                                                                      // 2022
                                                                                                               // 2023
        //This module may not have dependencies                                                                // 2024
        if (!isArray(deps)) {                                                                                  // 2025
            callback = deps;                                                                                   // 2026
            deps = null;                                                                                       // 2027
        }                                                                                                      // 2028
                                                                                                               // 2029
        //If no name, and callback is a function, then figure out if it a                                      // 2030
        //CommonJS thing with dependencies.                                                                    // 2031
        if (!deps && isFunction(callback)) {                                                                   // 2032
            deps = [];                                                                                         // 2033
            //Remove comments from the callback string,                                                        // 2034
            //look for require calls, and pull them into the dependencies,                                     // 2035
            //but only if there are function args.                                                             // 2036
            if (callback.length) {                                                                             // 2037
                callback                                                                                       // 2038
                    .toString()                                                                                // 2039
                    .replace(commentRegExp, '')                                                                // 2040
                    .replace(cjsRequireRegExp, function (match, dep) {                                         // 2041
                        deps.push(dep);                                                                        // 2042
                    });                                                                                        // 2043
                                                                                                               // 2044
                //May be a CommonJS thing even without require calls, but still                                // 2045
                //could use exports, and module. Avoid doing exports and module                                // 2046
                //work though if it just needs require.                                                        // 2047
                //REQUIRES the function to expect the CommonJS variables in the                                // 2048
                //order listed below.                                                                          // 2049
                deps = (callback.length === 1 ? ['require'] : ['require', 'exports', 'module']).concat(deps);  // 2050
            }                                                                                                  // 2051
        }                                                                                                      // 2052
                                                                                                               // 2053
        //If in IE 6-8 and hit an anonymous define() call, do the interactive                                  // 2054
        //work.                                                                                                // 2055
        if (useInteractive) {                                                                                  // 2056
            node = currentlyAddingScript || getInteractiveScript();                                            // 2057
            if (node) {                                                                                        // 2058
                if (!name) {                                                                                   // 2059
                    name = node.getAttribute('data-requiremodule');                                            // 2060
                }                                                                                              // 2061
                context = contexts[node.getAttribute('data-requirecontext')];                                  // 2062
            }                                                                                                  // 2063
        }                                                                                                      // 2064
                                                                                                               // 2065
        //Always save off evaluating the def call until the script onload handler.                             // 2066
        //This allows multiple modules to be in a file without prematurely                                     // 2067
        //tracing dependencies, and allows for anonymous module support,                                       // 2068
        //where the module name is not known until the script onload event                                     // 2069
        //occurs. If no context, use the global queue, and get it processed                                    // 2070
        //in the onscript load callback.                                                                       // 2071
        (context ? context.defQueue : globalDefQueue).push([name, deps, callback]);                            // 2072
    };                                                                                                         // 2073
                                                                                                               // 2074
    define.amd = {                                                                                             // 2075
        jQuery: true                                                                                           // 2076
    };                                                                                                         // 2077
                                                                                                               // 2078
                                                                                                               // 2079
    /**                                                                                                        // 2080
     * Executes the text. Normally just uses eval, but can be modified                                         // 2081
     * to use a better, environment-specific call. Only used for transpiling                                   // 2082
     * loader plugins, not for plain JS modules.                                                               // 2083
     * @param {String} text the text to execute/evaluate.                                                      // 2084
     */                                                                                                        // 2085
    req.exec = function (text) {                                                                               // 2086
        /*jslint evil: true */                                                                                 // 2087
        return eval(text);                                                                                     // 2088
    };                                                                                                         // 2089
                                                                                                               // 2090
    //Set up with config info.                                                                                 // 2091
    req(cfg);                                                                                                  // 2092
}(this));                                                                                                      // 2093
                                                                                                               // 2094
////////////////////////////////////////////////////////////////////////////////////////////////////           // 2095
// END ORGINAL SCRIPT                                                                                          // 2096
////////////////////////////////////////////////////////////////////////////////////////////////////           // 2097
                                                                                                               // 2098
// Return exports.                                                                                             // 2099
return {define: define, require: require, requirejs: requirejs};                                               // 2100
                                                                                                               // 2101
})();                                                                                                          // 2102
                                                                                                               // 2103
define = exports.define;                                                                                       // 2104
require = exports.require;                                                                                     // 2105
requirejs = exports.requirejs;                                                                                 // 2106
                                                                                                               // 2107
})(this);                                                                                                      // 2108
                                                                                                               // 2109
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////      // 2118
                                                                                                                       // 2119
}).call(this);                                                                                                         // 2120
                                                                                                                       // 2121
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['aramk:requirejs'] = {
  define: define,
  requirejs: requirejs
};

})();

//# sourceMappingURL=aramk_requirejs.js.map
