(function(){
Meteor.publish("logs", function () {
	return Logs.find({}, {
		limit: 1000,
		sort: { createdAt: -1 }
	});
});
}).call(this);

//# sourceMappingURL=publications.js.map
