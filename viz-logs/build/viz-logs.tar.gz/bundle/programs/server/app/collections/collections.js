(function(){
Logs = new Mongo.Collection("logs");
}).call(this);

//# sourceMappingURL=collections.js.map
