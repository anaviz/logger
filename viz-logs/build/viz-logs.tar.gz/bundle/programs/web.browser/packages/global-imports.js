/* Imports for global scope */

Router = Package['iron:router'].Router;
RouteController = Package['iron:router'].RouteController;
define = Package['aramk:requirejs'].define;
require = Package['aramk:requirejs'].require;
requirejs = Package['aramk:requirejs'].requirejs;
moment = Package['momentjs:moment'].moment;
_ = Package.underscore._;
Mongo = Package.mongo.Mongo;
Session = Package.session.Session;
$ = Package.jquery.$;
jQuery = Package.jquery.jQuery;
Tracker = Package.tracker.Tracker;
Deps = Package.tracker.Deps;
Log = Package.logging.Log;
Reload = Package.reload.Reload;
Random = Package.random.Random;
EJSON = Package.ejson.EJSON;
Spacebars = Package.spacebars.Spacebars;
check = Package.check.check;
Match = Package.check.Match;
Iron = Package['iron:core'].Iron;
Meteor = Package.meteor.Meteor;
WebApp = Package.webapp.WebApp;
DDP = Package['ddp-client'].DDP;
LaunchScreen = Package['launch-screen'].LaunchScreen;
Blaze = Package.ui.Blaze;
UI = Package.ui.UI;
Handlebars = Package.ui.Handlebars;
Template = Package.templating.Template;
Autoupdate = Package.autoupdate.Autoupdate;
HTML = Package.htmljs.HTML;

