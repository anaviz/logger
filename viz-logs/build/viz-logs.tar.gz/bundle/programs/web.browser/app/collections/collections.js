(function(){
Logs = new Mongo.Collection("logs");
}).call(this);
