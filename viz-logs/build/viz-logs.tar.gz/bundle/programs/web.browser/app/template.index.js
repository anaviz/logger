(function(){
Template.body.addContent((function() {
  var view = this;
  return Spacebars.include(view.lookupTemplate("menu"));
}));
Meteor.startup(Template.body.renderToDocument);

})();
