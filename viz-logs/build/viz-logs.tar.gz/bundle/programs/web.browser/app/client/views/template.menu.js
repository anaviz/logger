(function(){
Template.__checkName("menu");
Template["menu"] = new Template("Template.menu", (function() {
  var view = this;
  return HTML.DIV({
    "class": "menu"
  }, HTML.Raw('\n		<div class="menu-icon">\n			<div class="menu-icon-image"></div>\n		</div>\n		'), HTML.DIV({
    id: "menu"
  }, "\n			", Blaze.Each(function() {
    return Spacebars.call(view.lookup("items"));
  }, function() {
    return [ "\n				", HTML.A({
      id: function() {
        return Spacebars.mustache(view.lookup("id"));
      },
      "class": "nav-item",
      href: function() {
        return [ "/logs/", Spacebars.mustache(view.lookup("componentId")) ];
      }
    }, "\n					", Blaze.View("lookup:title", function() {
      return Spacebars.mustache(view.lookup("title"));
    }), "\n				"), "\n			" ];
  }), "\n		"), HTML.Raw('\n		<div class="underlay"></div>\n	'));
}));

}).call(this);
