(function(){
Template.__checkName("logs");
Template["logs"] = new Template("Template.logs", (function() {
  var view = this;
  return [ HTML.DIV({
    "class": "filter-container"
  }, "\n		", HTML.Raw('<div class="clear-logs" title="Clear logs"></div>'), "\n		", HTML.Raw('<div class="filter-operators switcher">\n			<div class="switcher-option active" data-switcher-option="and"> and </div>\n			<div class="switcher-option" data-switcher-option="or"> or </div>\n		</div>'), "\n		", HTML.Raw('<input class="filter-input" type="text">'), "\n		", HTML.DIV({
    "class": "filters"
  }, "\n			", Blaze.Each(function() {
    return Spacebars.call(view.lookup("filters"));
  }, function() {
    return [ "\n				", HTML.DIV({
      "class": "filter"
    }, "\n					", HTML.DIV({
      "class": "filter-pattern"
    }, Blaze.View("lookup:pattern", function() {
      return Spacebars.mustache(view.lookup("pattern"));
    })), "\n					", HTML.DIV({
      "class": "delete button",
      "data-filter-pattern": function() {
        return Spacebars.mustache(view.lookup("pattern"));
      }
    }, " X "), "\n				"), "\n			" ];
  }), "\n		"), "\n	"), "\n\n	", HTML.DIV({
    "class": function() {
      return [ "logs ", Spacebars.mustache(view.lookup("diffComponents")) ];
    }
  }, "\n		", Blaze.Each(function() {
    return Spacebars.call(view.lookup("logs"));
  }, function() {
    return [ "\n		", HTML.DIV({
      "class": function() {
        return [ "log ", Spacebars.mustache(view.lookup("component")) ];
      }
    }, "\n			", HTML.DIV({
      "class": "date"
    }, Blaze.View("lookup:formatDate", function() {
      return Spacebars.mustache(view.lookup("formatDate"), view.lookup("createdAt"));
    })), "\n			", HTML.DIV({
      "class": "message"
    }, Blaze.View("lookup:msg", function() {
      return Spacebars.mustache(view.lookup("msg"));
    })), "\n\n			", HTML.DIV({
      "class": "meta ip"
    }, Blaze.View("lookup:ip", function() {
      return Spacebars.mustache(view.lookup("ip"));
    })), "\n			", HTML.DIV({
      "class": "meta host"
    }, Blaze.View("lookup:host", function() {
      return Spacebars.mustache(view.lookup("host"));
    })), "\n			", HTML.DIV({
      "class": "meta id"
    }, Blaze.View("lookup:id", function() {
      return Spacebars.mustache(view.lookup("id"));
    })), "\n			", HTML.DIV({
      "class": "meta component"
    }, Blaze.View("lookup:component", function() {
      return Spacebars.mustache(view.lookup("component"));
    })), "\n		"), "\n		" ];
  }), "\n	") ];
}));

}).call(this);
